# Seasonal Trees for URP – Spring / Autumn / Winter

Tested target: **Unity 6 (6000.0 – 6000.3), Universal Render Pipeline**. Also written for 2022.3 / URP 14.

```
Assets/SeasonalTrees/
  Shaders/   SeasonalTreeBark.shader, SeasonalTreeLeaves.shader, SeasonalTreeCommon.hlsl, SeasonalTreePasses.hlsl
  Scripts/   SeasonManager.cs, LeafCarpet.cs
  Models/    Tree_763370.fbx, Tree_218845.fbx, Tree_590412.fbx   (LOD0/1/2, submeshes: Bark + Leaves)
  Textures/  LeafParticleAtlas.png                                 (2x2 leaf shapes for the particles)
```

Scripts can live in any folder under `Assets/` (not in an `Editor` folder). If you use Assembly
Definitions and the new Input System, add a reference to `Unity.InputSystem`.

---

## 1. Materials (one for bark, one for leaves – shared by all trees)

1. Project window → `Assets/SeasonalTrees` → right-click → **Create → Material** → name it `M_TreeBark`.
   Inspector → **Shader** dropdown → `SeasonalTree/Bark`.
2. Create a second material `M_TreeLeaves` → Shader `SeasonalTree/Leaves`.
3. On **both** materials:
   - **Tree Height** = height of your tree in metres (4.5 is fine for the included trees). Use the
     same value on bark and leaves, otherwise leaves sway away from their branches.
   - **Enable GPU Instancing** ✓ (bottom of the material Inspector).
4. `M_TreeBark`: keep **Use Vertex Color** = 1 for the included trees (their bark colour is stored in
   vertex colours). For your own trees with a bark texture, set **Bark Texture** and Use Vertex Color = 0.
   Snow settings: *Full Snow Reaches Down To* 0.15, *Snow Edge Softness* 0.08, *Snow Thickness* 0.02.
5. `M_TreeLeaves`: colours are ready to use. *Blossom Density* controls how many leaves become
   blossoms in spring. *Cull* = Back (the included leaves are already modelled double-sided).

## 2. Import the tree models

Select each `Tree_*.fbx` → Inspector:

- **Model** tab: Scale Factor 1, **Convert Units ✓**, **Import Normals = Import**,
  Mesh Compression Off, Read/Write off. Click **Apply**.
- **Materials** tab: under **Remapped Materials**, drag `M_TreeBark` onto **Bark** and
  `M_TreeLeaves` onto **Leaves** (keep Material Creation Mode = Import via MaterialDescription).
  Click **Apply**.

Drag the FBX into the scene. Unity creates a **LOD Group** from the `_LOD0/_LOD1/_LOD2` names.
In the LOD Group set the transitions (many trees on PC): LOD0 → **40 %**, LOD1 → **12 %**,
Culled → **1.5 %**. Optional: **Fade Mode = Cross Fade** (the shaders support it).
Turn the configured tree into a prefab and place copies.

## 3. Season Manager

1. Hierarchy → **Create Empty** → name `SeasonManager` → **Add Component → Season Manager**.
2. Inspector:
   - **Season**: Spring / Autumn / Winter. Changing it in Play mode starts a smooth transition;
     in Edit mode it previews instantly in the Scene view.
   - **Transition Duration**: 8 s. **Leaves Start Falling At**: 0.5 (halfway into autumn).
   - Keys (Play mode): **N** = next season, **1/2/3** = Spring/Autumn/Winter.
   - **Wind Direction**: world direction the wind blows towards.
   - **Spring / Autumn / Winter** blocks: the values each season blends to (autumn colour, blossoms,
     leaf dissolve, snow, wind strength/speed, leaf flutter, falling leaves on/off).
3. Only one SeasonManager per scene. Trees and particle systems need no reference to it:
   it drives every tree material through global shader values and finds all `LeafCarpet` systems.

From code: `FindObjectOfType<SeasonalTrees.SeasonManager>().SetSeason(SeasonManager.Season.Winter);`

## 4. Falling autumn leaves (Particle System)

### 4a. Ground
- The ground (Plane, mesh or Terrain) needs a **Collider** (MeshCollider/TerrainCollider).
- Put it on its own layer: top-right **Layer → Add Layer…** → `Ground`, assign it to the ground.

### 4b. Particle material
Create material `M_LeafParticle`:
- Shader **Universal Render Pipeline/Particles/Simple Lit**
- **Surface Type** Opaque, **Render Face** Both, **Alpha Clipping ✓**, Threshold **0.5**
- **Base Map** = `LeafParticleAtlas.png`, colour white, **Color Mode** Multiply
- `LeafParticleAtlas.png` import settings: **Alpha Is Transparency ✓**, Wrap Mode Clamp → Apply.

### 4c. Create the system
Select the tree prefab → right-click → **Effects → Particle System**, name it `FallingLeaves`.
Transform: Position **(0, 3.1, 0)** (canopy centre for the included trees), Rotation (0, 0, 0).
**Add Component → Leaf Carpet** on the same GameObject.

### 4d. Module settings (unlisted = default)

**Main**
| Setting | Value |
|---|---|
| Duration | 10, Looping ✓, Prewarm ✗ |
| Start Lifetime | 15 (max time in the air – Leaf Carpet adds ground time) |
| Start Speed | Random Between Two Constants 0 – 0.2 |
| 3D Start Size | ✗, Start Size Random 0.12 – 0.22 |
| 3D Start Rotation | ✓, each axis Random 0 – 360 |
| Start Color | Random Between Two Gradients/Colors: yellow (255,200,40) … red (200,50,20) – or a gradient yellow→orange→red with "Random Color" |
| Gravity Source / Modifier | 3D Physics, **0.08** |
| Simulation Space | **World** (important – landed leaves must not move with the tree) |
| Scaling Mode | Hierarchy |
| Play On Awake | ✗ (SeasonManager starts it) |
| Max Particles | 300 |
| Culling Mode | Pause and Catch-up |

**Emission**: Rate over Time **8**.

**Shape**: Sphere, Radius **1.4**, Radius Thickness **0.3**, Scale **(1, 0.7, 1)**.

**Limit Velocity over Lifetime** ✓: Speed 1.2, Dampen 0.2, **Drag 1.5**, Multiply by Size ✗
(gives leaves their slow, floating fall).

**Rotation over Lifetime** ✓: Separate Axes ✓, X/Y/Z Random Between Two Constants **-120 … 120**.

**Noise** ✓ (the swirl):
| Setting | Value |
|---|---|
| Separate Axes | ✗ |
| Strength | **0.8** |
| Frequency | **0.35** |
| Scroll Speed | 0.25 |
| Damping | ✓ |
| Octaves | 2 |
| Quality | Medium (2D) is enough; High for hero shots |
| Position Amount | 1, **Rotation Amount 0.4**, Size Amount 0 |

**Collision** ✓ (the leaf carpet):
| Setting | Value |
|---|---|
| Type | **World** (or **Planes** with the ground transform for a flat ground – cheaper) |
| Mode | 3D |
| **Dampen** | **1** |
| **Bounce** | **0** |
| **Lifetime Loss** | **0** |
| Min Kill Speed | 0 |
| Max Kill Speed | 10000 |
| Radius Scale | 0.1 |
| Quality | Medium (Static Colliders) for a static ground; High if the ground moves |
| **Collides With** | **Ground** only (so leaves don't stick to trunks or other trees) |
| Enable Dynamic Colliders | ✗ |
| **Send Collision Messages** | **✓** (required by Leaf Carpet) |

**Texture Sheet Animation** ✓: Mode Grid, Tiles **2 × 2**, Animation Whole Sheet,
Frame over Time **Constant 0**, **Start Frame Random Between Two Constants 0 – 3**, Cycles 1.

**Renderer**:
| Setting | Value |
|---|---|
| Render Mode | **Mesh**, Mesh = **Quad** |
| Material | `M_LeafParticle` |
| Render Alignment | **World** |
| Enable Mesh GPU Instancing | ✓ |
| Cast Shadows | Off (cheap) – On for hero trees |
| Receive Shadows | ✓ |

**Leaf Carpet** component: Carpet Seconds **30**, Shrink Seconds 3, Ground Offset 0.01,
Match Radius 0.35, Landed Tilt 8.

### Why the Leaf Carpet script is needed
Dampen 1 / Bounce 0 / Lifetime Loss 0 stops a leaf when it touches the ground, but Unity keeps
applying Noise, Gravity and Rotation to it every frame, so it would creep and spin on the floor and
still die at its normal lifetime. Leaf Carpet reads each landing from the collision messages, pins
the leaf flat at that spot, gives it `Carpet Seconds` of extra life and shrinks it away at the end.
When autumn ends, emission stops but leaves on the ground stay until their time runs out.

### Performance (many trees)
Each system costs CPU (noise + world collision). Put Falling Leaves only on trees near the
player or on a few hero trees, or use one larger system (bigger Shape box) for a whole group of
trees. Keep `Max Particles × number of systems` around 1–2k on PC.

---

## How the shaders work

- **Season values are global** (`_TS_AutumnBlend`, `_TS_LeafDissolve`, `_TS_SnowAmount`, wind…),
  set by SeasonManager with `Shader.SetGlobal*`. Materials only hold the look (colours, snow
  settings), so seasons never get saved into your material assets and one manager drives all trees.
- **Spring**: `Spring Color` shaded by the light/dark vertex colours; blossoms replace a random set
  of leaves (each leaf has its own random ID in UV2).
- **Autumn**: each leaf turns at its own moment (leaf ID + world-space noise), so colour sweeps
  through the crown; colour patches from noise pick yellow → orange → red.
- **Winter**: leaves dry to brown and then disappear one by one (alpha clip on the leaf ID; canopy
  filler shapes use world noise). Snow covers bark where the world normal points up
  (`normal.y` vs. a threshold that lowers as snow increases), with a noisy edge and slight thickness.
- **Wind**: the whole tree bends with height² (roots don't move) using identical code in both
  shaders, plus per-leaf flutter on leaves only. Shadow, depth and depth-normals passes apply the
  same wind and dissolve, so shadows and SSAO match.
- Supports SRP Batcher, GPU instancing, LOD cross-fade, shadows, additional lights, Forward+ and fog.
