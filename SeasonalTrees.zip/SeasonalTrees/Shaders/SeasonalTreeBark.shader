// Seasonal tree BARK for URP (Unity 6 / URP 17; also written for 2022.3 / URP 14).
// Vertex-colour or texture bark, the same wind bend as the leaves, and winter snow that builds up
// on upward-facing surfaces (world normal Y) of the trunk, branches and roots.
// Season state comes from the global _TS_* values set by SeasonManager.cs.
Shader "SeasonalTree/Bark"
{
    Properties
    {
        [Header(Bark)]
        _BaseMap("Bark Texture (UV0, leave white for the generated trees)", 2D) = "white" {}
        _BaseColor("Bark Tint", Color) = (1, 1, 1, 1)
        _UseVertexColor("Use Vertex Color", Range(0, 1)) = 1
        _Smoothness("Smoothness", Range(0, 1)) = 0.2

        [Header(Winter Snow)]
        _SnowColor("Snow Color", Color) = (0.94, 0.96, 1.0, 1)
        _SnowSmoothness("Snow Smoothness", Range(0, 1)) = 0.35
        _SnowMinNormalY("Full Snow Reaches Down To (normal Y)", Range(-1, 1)) = 0.15
        _SnowSharpness("Snow Edge Softness", Range(0.01, 0.5)) = 0.08
        _SnowNoiseScale("Snow Edge Noise Scale (1/m)", Float) = 6
        _SnowThickness("Snow Thickness (m)", Range(0, 0.1)) = 0.02

        [Header(Wind)]
        _TreeHeight("Tree Height in metres (same value on Leaves)", Float) = 4.5
    }

    SubShader
    {
        Tags
        {
            "RenderPipeline" = "UniversalPipeline"
            "RenderType" = "Opaque"
            "Queue" = "Geometry"
            "UniversalMaterialType" = "Lit"
        }
        LOD 300

        HLSLINCLUDE
        #include "SeasonalTreeCommon.hlsl"

        TEXTURE2D(_BaseMap);
        SAMPLER(sampler_BaseMap);

        CBUFFER_START(UnityPerMaterial)
            float4 _BaseMap_ST;
            half4  _BaseColor;
            half   _UseVertexColor;
            half   _Smoothness;
            half4  _SnowColor;
            half   _SnowSmoothness;
            half   _SnowMinNormalY;
            half   _SnowSharpness;
            float  _SnowNoiseScale;
            float  _SnowThickness;
            float  _TreeHeight;
        CBUFFER_END

        // 0..1 snow coverage. With more snow the threshold moves from "only perfectly flat tops"
        // down to _SnowMinNormalY; noise breaks up the edge.
        float TS_SnowMask(float normalY, float3 positionWS)
        {
            float amount = _TS_SnowAmount;
            float n = TS_ValueNoise(positionWS * _SnowNoiseScale) - 0.5;
            float threshold = lerp(1.0 + _SnowSharpness, _SnowMinNormalY, amount);
            return smoothstep(threshold - _SnowSharpness, threshold + _SnowSharpness, normalY + n * 0.3)
                 * saturate(amount * 4.0);
        }

        float3 TS_DisplaceWS(float3 positionWS, float3 positionOS, float3 normalWS, float leafId)
        {
            // Snow adds a little volume on top surfaces (applied before wind so it sways with the bark).
            positionWS += normalWS * (_SnowThickness * TS_SnowMask(normalWS.y, positionWS));
            return TS_ApplyWind(positionWS, positionOS, normalWS, _TreeHeight, 0.0, -1.0);
        }

        void TS_AlphaClip(float3 positionWS, float leafId) { }

        void TS_SurfaceColor(float3 positionWS, float3 normalWS, half4 vertexColor, float2 uv,
                             float leafId, out half3 albedo, out half smoothness)
        {
            half3 bark = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, TRANSFORM_TEX(uv, _BaseMap)).rgb * _BaseColor.rgb;
            bark *= lerp(half3(1, 1, 1), TS_VertexColorToLinear(vertexColor.rgb), _UseVertexColor);

            float snow = TS_SnowMask(normalWS.y, positionWS);
            albedo = lerp(bark, _SnowColor.rgb, snow);
            smoothness = lerp(_Smoothness, _SnowSmoothness, snow);
        }
        ENDHLSL

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode" = "UniversalForward" }

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSForwardFragment

            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX _ADDITIONAL_LIGHTS
            #pragma multi_compile_fragment _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile_fragment _ _SHADOWS_SOFT _SHADOWS_SOFT_LOW _SHADOWS_SOFT_MEDIUM _SHADOWS_SOFT_HIGH
            #pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
            #pragma multi_compile _ _LIGHT_LAYERS
            // Unity 6.0 uses _FORWARD_PLUS, Unity 6.1+ renamed it to _CLUSTER_LIGHT_LOOP.
            #pragma multi_compile _ _FORWARD_PLUS
            #pragma multi_compile _ _CLUSTER_LIGHT_LOOP
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_fog
            #pragma multi_compile_instancing

            #define TS_PASS_FORWARD
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "ShadowCaster"
            Tags { "LightMode" = "ShadowCaster" }
            ZWrite On
            ZTest LEqual
            ColorMask 0

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthFragment
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_instancing

            #define TS_PASS_SHADOWCASTER
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "DepthOnly"
            Tags { "LightMode" = "DepthOnly" }
            ZWrite On
            ColorMask R

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthFragment
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_instancing

            #define TS_PASS_DEPTHONLY
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "DepthNormals"
            Tags { "LightMode" = "DepthNormals" }
            ZWrite On

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthNormalsFragment
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_fragment _ _GBUFFER_NORMALS_OCT
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
            #pragma multi_compile_instancing

            #define TS_PASS_DEPTHNORMALS
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }
    }

    FallBack "Hidden/Universal Render Pipeline/FallbackError"
}
