#ifndef SEASONAL_TREE_PASSES_INCLUDED
#define SEASONAL_TREE_PASSES_INCLUDED

// Vertex/fragment programs shared by both seasonal tree shaders.
// The including shader must define, before including this file:
//   float3 TS_DisplaceWS(float3 positionWS, float3 positionOS, float3 normalWS, float leafId)
//   void   TS_AlphaClip(float3 positionWS, float leafId)            (may be empty)
//   void   TS_SurfaceColor(float3 positionWS, float3 normalWS, half4 vertexColor, float2 uv,
//                           float leafId, out half3 albedo, out half smoothness)
// and exactly one of TS_PASS_FORWARD / TS_PASS_SHADOWCASTER / TS_PASS_DEPTHONLY / TS_PASS_DEPTHNORMALS.

#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
#if defined(LOD_FADE_CROSSFADE)
    #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/LODCrossFade.hlsl"
#endif

struct TSAttributes
{
    float4 positionOS : POSITION;
    float3 normalOS   : NORMAL;
    half4  color      : COLOR;
    float2 uv         : TEXCOORD0;
    float2 leafData   : TEXCOORD1;   // x = per-leaf random ID in [0,1), -1 = bark / canopy blob
    UNITY_VERTEX_INPUT_INSTANCE_ID
};

struct TSVaryings
{
    float4 positionCS  : SV_POSITION;
    float3 positionWS  : TEXCOORD0;
    float3 normalWS    : TEXCOORD1;
    half4  color       : TEXCOORD2;
    float2 uv          : TEXCOORD3;
    float  leafId      : TEXCOORD4;
#if defined(TS_PASS_FORWARD)
    half   fogFactor   : TEXCOORD5;
    #if defined(REQUIRES_VERTEX_SHADOW_COORD_INTERPOLATOR)
    float4 shadowCoord : TEXCOORD6;
    #endif
#endif
    UNITY_VERTEX_INPUT_INSTANCE_ID
    UNITY_VERTEX_OUTPUT_STEREO
};

#if defined(TS_PASS_SHADOWCASTER)
// Set by URP for the shadow-casting light (same as the built-in ShadowCasterPass.hlsl).
float3 _LightDirection;
float3 _LightPosition;
#endif

TSVaryings TSVertex(TSAttributes input)
{
    TSVaryings output = (TSVaryings)0;
    UNITY_SETUP_INSTANCE_ID(input);
    UNITY_TRANSFER_INSTANCE_ID(input, output);
    UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

    float3 positionWS = TransformObjectToWorld(input.positionOS.xyz);
    float3 normalWS = TransformObjectToWorldNormal(input.normalOS);
    positionWS = TS_DisplaceWS(positionWS, input.positionOS.xyz, normalWS, input.leafData.x);

    output.positionWS = positionWS;
    output.normalWS = normalWS;
    output.color = input.color;
    output.uv = input.uv;
    output.leafId = input.leafData.x;

#if defined(TS_PASS_SHADOWCASTER)
    #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
        float3 lightDirectionWS = normalize(_LightPosition - positionWS);
    #else
        float3 lightDirectionWS = _LightDirection;
    #endif
    float4 positionCS = TransformWorldToHClip(ApplyShadowBias(positionWS, normalWS, lightDirectionWS));
    output.positionCS = ApplyShadowClamping(positionCS);
#else
    output.positionCS = TransformWorldToHClip(positionWS);
#endif

#if defined(TS_PASS_FORWARD)
    output.fogFactor = ComputeFogFactor(output.positionCS.z);
    #if defined(REQUIRES_VERTEX_SHADOW_COORD_INTERPOLATOR)
        VertexPositionInputs vpi = (VertexPositionInputs)0;
        vpi.positionWS = positionWS;
        vpi.positionCS = output.positionCS;
        output.shadowCoord = GetShadowCoord(vpi);
    #endif
#endif
    return output;
}

void TSCommonFragment(TSVaryings input)
{
    UNITY_SETUP_INSTANCE_ID(input);
    UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
    TS_AlphaClip(input.positionWS, input.leafId);
#if defined(LOD_FADE_CROSSFADE)
    LODFadeCrossFade(input.positionCS);
#endif
}

#if defined(TS_PASS_FORWARD)
half4 TSForwardFragment(TSVaryings input) : SV_Target
{
    TSCommonFragment(input);

    half3 albedo;
    half smoothness;
    TS_SurfaceColor(input.positionWS, normalize(input.normalWS), input.color, input.uv, input.leafId,
                    albedo, smoothness);

    InputData inputData = (InputData)0;
    inputData.positionWS = input.positionWS;
    inputData.positionCS = input.positionCS;
    inputData.normalWS = NormalizeNormalPerPixel(input.normalWS);
    inputData.viewDirectionWS = GetWorldSpaceNormalizeViewDir(input.positionWS);
#if defined(REQUIRES_VERTEX_SHADOW_COORD_INTERPOLATOR)
    inputData.shadowCoord = input.shadowCoord;
#elif defined(MAIN_LIGHT_CALCULATE_SHADOWS)
    inputData.shadowCoord = TransformWorldToShadowCoord(input.positionWS);
#else
    inputData.shadowCoord = float4(0, 0, 0, 0);
#endif
    inputData.fogCoord = InitializeInputDataFog(float4(input.positionWS, 1.0), input.fogFactor);
    inputData.bakedGI = SampleSH(inputData.normalWS);
    inputData.normalizedScreenSpaceUV = GetNormalizedScreenSpaceUV(input.positionCS);
    inputData.shadowMask = half4(1, 1, 1, 1);

    SurfaceData surface = (SurfaceData)0;
    surface.albedo = albedo;
    surface.metallic = 0;
    surface.specular = half3(0, 0, 0);
    surface.smoothness = smoothness;
    surface.normalTS = half3(0, 0, 1);
    surface.occlusion = 1;
    surface.alpha = 1;

    half4 color = UniversalFragmentPBR(inputData, surface);
    color.rgb = MixFog(color.rgb, inputData.fogCoord);
    color.a = 1;
    return color;
}
#endif

#if defined(TS_PASS_SHADOWCASTER) || defined(TS_PASS_DEPTHONLY)
half4 TSDepthFragment(TSVaryings input) : SV_Target
{
    TSCommonFragment(input);
    return 0;
}
#endif

// Unity 6.2 changed the rendering-layers output from float4 to uint.
#if UNITY_VERSION >= 600020
    #define TS_RENDERING_LAYERS_TYPE uint
    #define TS_ENCODE_RENDERING_LAYERS() EncodeMeshRenderingLayer()
#else
    #define TS_RENDERING_LAYERS_TYPE float4
    #define TS_ENCODE_RENDERING_LAYERS() float4(EncodeMeshRenderingLayer(GetMeshRenderingLayer()), 0, 0, 0)
#endif

#if defined(TS_PASS_DEPTHNORMALS)
void TSDepthNormalsFragment(TSVaryings input
    , out half4 outNormalWS : SV_Target0
#ifdef _WRITE_RENDERING_LAYERS
    , out TS_RENDERING_LAYERS_TYPE outRenderingLayers : SV_Target1
#endif
)
{
    TSCommonFragment(input);
    float3 normalWS = NormalizeNormalPerPixel(input.normalWS);
#if defined(_GBUFFER_NORMALS_OCT)
    float2 octNormalWS = PackNormalOctQuadEncode(normalWS);
    float2 remappedOctNormalWS = saturate(octNormalWS * 0.5 + 0.5);
    outNormalWS = half4(PackFloat2To888(remappedOctNormalWS), 0.0);
#else
    outNormalWS = half4(normalWS, 0.0);
#endif
#ifdef _WRITE_RENDERING_LAYERS
    outRenderingLayers = TS_ENCODE_RENDERING_LAYERS();
#endif
}
#endif

#endif // SEASONAL_TREE_PASSES_INCLUDED
