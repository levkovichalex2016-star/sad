#ifndef SEASONAL_TREE_COMMON_INCLUDED
#define SEASONAL_TREE_COMMON_INCLUDED

// Shared by SeasonalTree/Bark and SeasonalTree/Leaves.
// Bark and leaves MUST use the same wind code and the same _TreeHeight, otherwise the leaves
// would drift away from the branches while swaying.

#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include "Packages/com.unity.render-pipelines.core/ShaderLibrary/Color.hlsl"

// ---------------------------------------------------------------------------------------------
// Global season state, written every frame by SeasonManager via Shader.SetGlobalFloat/Vector.
// Deliberately NOT declared in the Properties block or the material CBUFFER: a material value
// would override the global, and every tree in the scene must follow the same season.
// Unset globals read as 0 = static spring trees without wind.
// ---------------------------------------------------------------------------------------------
float  _TS_AutumnBlend;      // 0 = spring colours, 1 = full autumn colours
float  _TS_BlossomAmount;    // 0..1 pink/white blossom accents (spring)
float  _TS_LeafDissolve;     // 0 = full canopy, 1 = all leaves gone (winter)
float  _TS_SnowAmount;       // 0..1 snow on top-facing bark
float  _TS_WindStrength;     // trunk/branch bend in metres at the tree top
float  _TS_WindSpeed;        // sway frequency multiplier
float  _TS_FlutterStrength;  // per-leaf flutter in metres
float4 _TS_WindDirection;    // world-space XZ direction (y ignored)

// ---------------------------------------------------------------------------------------------
// Noise
// ---------------------------------------------------------------------------------------------
float TS_Hash13(float3 p)
{
    p = frac(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return frac((p.x + p.y) * p.z);
}

float TS_Hash11(float x)
{
    return frac(sin(x * 127.1 + 311.7) * 43758.5453);
}

// Smooth value noise in [0, 1).
float TS_ValueNoise(float3 p)
{
    float3 i = floor(p);
    float3 f = frac(p);
    float3 u = f * f * (3.0 - 2.0 * f);

    float n000 = TS_Hash13(i + float3(0, 0, 0));
    float n100 = TS_Hash13(i + float3(1, 0, 0));
    float n010 = TS_Hash13(i + float3(0, 1, 0));
    float n110 = TS_Hash13(i + float3(1, 1, 0));
    float n001 = TS_Hash13(i + float3(0, 0, 1));
    float n101 = TS_Hash13(i + float3(1, 0, 1));
    float n011 = TS_Hash13(i + float3(0, 1, 1));
    float n111 = TS_Hash13(i + float3(1, 1, 1));

    float nx00 = lerp(n000, n100, u.x);
    float nx10 = lerp(n010, n110, u.x);
    float nx01 = lerp(n001, n101, u.x);
    float nx11 = lerp(n011, n111, u.x);
    return min(lerp(lerp(nx00, nx10, u.y), lerp(nx01, nx11, u.y), u.z), 0.9999);
}

// ---------------------------------------------------------------------------------------------
// Wind: the whole tree bends away from the wind (height^2 falloff keeps roots and trunk base
// fixed), each tree gets its own phase from its world position, and leaves add a small flutter.
// ---------------------------------------------------------------------------------------------
float3 TS_ApplyWind(float3 positionWS, float3 positionOS, float3 normalWS, float treeHeight,
                    float flutterWeight, float leafId)
{
    float3 originWS = TransformObjectToWorld(float3(0, 0, 0));
    float  h = saturate(positionOS.y / max(treeHeight, 0.01));
    float  bendWeight = h * h;

    float2 windDir = _TS_WindDirection.xz;
    windDir = dot(windDir, windDir) > 1e-6 ? normalize(windDir) : float2(1, 0);

    float t = _Time.y * _TS_WindSpeed;
    float phase = dot(originWS.xz, float2(0.37, 0.61));
    // Mostly leaning with the wind plus two sway frequencies and a slow gust envelope.
    float gust = 0.65 + 0.35 * sin(t * 0.31 + phase * 0.5);
    float sway = 0.55 + 0.35 * sin(t * 1.3 + phase) + 0.15 * sin(t * 2.9 + phase * 1.7);
    float2 bend = windDir * (_TS_WindStrength * bendWeight * sway * gust);
    // A small perpendicular component makes the motion elliptical instead of a flat pendulum.
    bend += float2(-windDir.y, windDir.x) * (_TS_WindStrength * 0.25 * bendWeight * sin(t * 1.1 + phase * 2.3));

    positionWS.xz += bend;
    // Approximate arc: as the top bends sideways it drops slightly, preserving the branch length.
    positionWS.y -= dot(bend, bend) * 0.5 / max(positionOS.y, 0.5);

    if (flutterWeight > 0)
    {
        float leafPhase = (leafId >= 0 ? leafId * 6.2831 : 0) + dot(positionWS, float3(1.7, 2.3, 1.3));
        float flutter = sin(_Time.y * (6.0 + 3.0 * _TS_WindSpeed) + leafPhase)
                      * 0.5 + 0.5 * sin(_Time.y * 11.0 + leafPhase * 1.9);
        positionWS += normalWS * (_TS_FlutterStrength * flutter * flutterWeight * h * gust);
    }
    return positionWS;
}

// Vertex colours come from the FBX in sRGB; convert to linear when the project is linear.
half3 TS_VertexColorToLinear(half3 c)
{
#if defined(UNITY_COLORSPACE_GAMMA)
    return c;
#else
    return SRGBToLinear(c);
#endif
}

#endif // SEASONAL_TREE_COMMON_INCLUDED
