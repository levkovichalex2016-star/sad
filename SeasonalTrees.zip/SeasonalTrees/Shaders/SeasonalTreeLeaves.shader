// Seasonal tree LEAVES for URP (Unity 6 / URP 17; also written for 2022.3 / URP 14).
// Spring colour + blossoms, staggered autumn colouring, winter dissolve, wind sway + leaf flutter.
// Season state comes from the global _TS_* values set by SeasonManager.cs.
Shader "SeasonalTree/Leaves"
{
    Properties
    {
        [Header(Spring)]
        _SpringColor("Spring Color", Color) = (0.45, 0.80, 0.22, 1)
        _BlossomPink("Blossom Pink", Color) = (1.0, 0.62, 0.78, 1)
        _BlossomWhite("Blossom White", Color) = (1.0, 0.97, 0.97, 1)
        _BlossomDensity("Blossom Density (at Blossom Amount 1)", Range(0, 1)) = 0.35

        [Header(Autumn)]
        _AutumnYellow("Autumn Yellow", Color) = (0.98, 0.78, 0.18, 1)
        _AutumnOrange("Autumn Orange", Color) = (0.95, 0.47, 0.10, 1)
        _AutumnRed("Autumn Red", Color) = (0.78, 0.16, 0.08, 1)
        _AutumnNoiseScale("Autumn Colour Patch Scale (1/m)", Float) = 0.6

        [Header(Winter Dissolve)]
        _DryColor("Dry Leaf Color (just before falling)", Color) = (0.47, 0.30, 0.13, 1)
        _DryRange("Dry Range", Range(0.01, 0.5)) = 0.12
        _BlobNoiseScale("Canopy Blob Dissolve Noise Scale (1/m)", Float) = 3

        [Header(Shading)]
        _Smoothness("Smoothness", Range(0, 1)) = 0.2
        _VertexShading("Use Vertex Color Shading", Range(0, 1)) = 1
        _ShadeReference("Shade Reference Luminance", Range(0.05, 1)) = 0.33
        _ShadeContrast("Shade Contrast", Range(0.5, 3)) = 1.6

        [Header(Wind)]
        _TreeHeight("Tree Height in metres (same value on Bark)", Float) = 4.5

        [Enum(UnityEngine.Rendering.CullMode)] _Cull("Cull", Float) = 2
    }

    SubShader
    {
        Tags
        {
            "RenderPipeline" = "UniversalPipeline"
            "RenderType" = "TransparentCutout"
            "Queue" = "AlphaTest"
            "UniversalMaterialType" = "Lit"
        }
        LOD 300
        Cull [_Cull]

        HLSLINCLUDE
        #include "SeasonalTreeCommon.hlsl"

        CBUFFER_START(UnityPerMaterial)
            half4 _SpringColor;
            half4 _BlossomPink;
            half4 _BlossomWhite;
            half  _BlossomDensity;
            half4 _AutumnYellow;
            half4 _AutumnOrange;
            half4 _AutumnRed;
            float _AutumnNoiseScale;
            half4 _DryColor;
            half  _DryRange;
            float _BlobNoiseScale;
            half  _Smoothness;
            half  _VertexShading;
            half  _ShadeReference;
            half  _ShadeContrast;
            float _TreeHeight;
            half  _Cull;
        CBUFFER_END

        // Value in [0,1) compared against _TS_LeafDissolve. Real leaves use their own ID so each
        // leaf drops as a whole; canopy blobs (no ID) use noise and finish a bit earlier (0.85).
        float TS_LeafLife(float3 positionWS, float leafId)
        {
            return leafId >= 0 ? leafId : 0.85 * TS_ValueNoise(positionWS * _BlobNoiseScale);
        }

        float3 TS_DisplaceWS(float3 positionWS, float3 positionOS, float3 normalWS, float leafId)
        {
            return TS_ApplyWind(positionWS, positionOS, normalWS, _TreeHeight, leafId >= 0 ? 1.0 : 0.0, leafId);
        }

        void TS_AlphaClip(float3 positionWS, float leafId)
        {
            clip(TS_LeafLife(positionWS, leafId) - _TS_LeafDissolve);
        }

        void TS_SurfaceColor(float3 positionWS, float3 normalWS, half4 vertexColor, float2 uv,
                             float leafId, out half3 albedo, out half smoothness)
        {
            bool hasId = leafId >= 0;
            float id = hasId ? leafId : TS_ValueNoise(positionWS * _BlobNoiseScale + 7.0);
            float region = TS_ValueNoise(positionWS * _AutumnNoiseScale + 17.0);

            // Light/dark variation baked into the vertex colours (sRGB luminance).
            half lum = dot(vertexColor.rgb, half3(0.299, 0.587, 0.114));
            half shade = min(pow(max(lum / _ShadeReference, 0.0), _ShadeContrast), 2.0);
            shade = lerp(1.0, shade, _VertexShading);

            // Autumn palette: colour patches across the crown plus per-leaf variation.
            float g = saturate(region * 0.75 + id * 0.45 - 0.15);
            half3 autumn = g < 0.5 ? lerp(_AutumnYellow.rgb, _AutumnOrange.rgb, g * 2.0)
                                   : lerp(_AutumnOrange.rgb, _AutumnRed.rgb, g * 2.0 - 1.0);
            // Each leaf turns at its own moment, so the change sweeps through the canopy.
            float turnAt = id * 0.55 + region * 0.25;
            float turn = smoothstep(turnAt, turnAt + 0.2, _TS_AutumnBlend);
            half3 color = lerp(_SpringColor.rgb, autumn, turn);
            color *= shade;

            // Spring blossoms on a random subset of leaves; they fade out as autumn arrives.
            if (hasId)
            {
                float pick = TS_Hash11(id * 91.7 + 3.1);
                float blossom = step(1.0 - _TS_BlossomAmount * _BlossomDensity, pick) * (1.0 - turn);
                half3 blossomColor = lerp(_BlossomPink.rgb, _BlossomWhite.rgb, step(0.5, TS_Hash11(id * 13.3)));
                color = lerp(color, blossomColor * lerp(shade, 1.0, 0.6), blossom);
            }

            // Leaves about to drop dry out to brown first.
            float life = TS_LeafLife(positionWS, leafId);
            float dry = (1.0 - saturate((life - _TS_LeafDissolve) / _DryRange)) * step(0.001, _TS_LeafDissolve);
            color = lerp(color, _DryColor.rgb * lerp(shade, 1.0, 0.5), dry);

            albedo = color;
            smoothness = _Smoothness;
        }
        ENDHLSL

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode" = "UniversalForward" }

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSForwardFragment

            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX _ADDITIONAL_LIGHTS
            #pragma multi_compile_fragment _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile_fragment _ _SHADOWS_SOFT _SHADOWS_SOFT_LOW _SHADOWS_SOFT_MEDIUM _SHADOWS_SOFT_HIGH
            #pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
            #pragma multi_compile _ _LIGHT_LAYERS
            // Unity 6.0 uses _FORWARD_PLUS, Unity 6.1+ renamed it to _CLUSTER_LIGHT_LOOP.
            #pragma multi_compile _ _FORWARD_PLUS
            #pragma multi_compile _ _CLUSTER_LIGHT_LOOP
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_fog
            #pragma multi_compile_instancing

            #define TS_PASS_FORWARD
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "ShadowCaster"
            Tags { "LightMode" = "ShadowCaster" }
            ZWrite On
            ZTest LEqual
            ColorMask 0

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthFragment
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_instancing

            #define TS_PASS_SHADOWCASTER
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "DepthOnly"
            Tags { "LightMode" = "DepthOnly" }
            ZWrite On
            ColorMask R

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthFragment
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_instancing

            #define TS_PASS_DEPTHONLY
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "DepthNormals"
            Tags { "LightMode" = "DepthNormals" }
            ZWrite On

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex TSVertex
            #pragma fragment TSDepthNormalsFragment
            #pragma multi_compile _ LOD_FADE_CROSSFADE
            #pragma multi_compile_fragment _ _GBUFFER_NORMALS_OCT
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"
            #pragma multi_compile_instancing

            #define TS_PASS_DEPTHNORMALS
            #include "SeasonalTreePasses.hlsl"
            ENDHLSL
        }
    }

    FallBack "Hidden/Universal Render Pipeline/FallbackError"
}
