using System;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace SeasonalTrees
{
    /// <summary>
    /// Switches every SeasonalTree/Bark and SeasonalTree/Leaves material in the scene between
    /// Spring, Autumn and Winter, and turns the falling-leaves particle systems on in Autumn.
    ///
    /// The season is written to GLOBAL shader properties (_TS_*), so one manager drives any
    /// number of trees and materials, and nothing is saved into your material assets.
    /// Put exactly one SeasonManager in the scene.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public class SeasonManager : MonoBehaviour
    {
        public enum Season { Spring, Autumn, Winter }

        /// <summary>All values that change between seasons. Edit them per season in the Inspector.</summary>
        [Serializable]
        public struct SeasonSettings
        {
            [Tooltip("0 = spring green, 1 = full autumn colours")]
            [Range(0f, 1f)] public float autumnColor;
            [Tooltip("Amount of pink/white blossom accents on the leaves")]
            [Range(0f, 1f)] public float blossoms;
            [Tooltip("0 = full canopy, 1 = all leaves dissolved away")]
            [Range(0f, 1f)] public float leafDissolve;
            [Tooltip("Snow on the top-facing surfaces of trunk, branches and roots")]
            [Range(0f, 1f)] public float snow;
            [Tooltip("How far the tree tops bend in the wind, in metres")]
            [Range(0f, 0.5f)] public float windStrength;
            [Tooltip("Sway speed multiplier")]
            [Range(0f, 4f)] public float windSpeed;
            [Tooltip("Small per-leaf flutter, in metres")]
            [Range(0f, 0.1f)] public float leafFlutter;
            [Tooltip("Falling-leaf particles emit during this season")]
            public bool fallingLeaves;

            public static SeasonSettings Lerp(SeasonSettings a, SeasonSettings b, float t)
            {
                return new SeasonSettings
                {
                    autumnColor = Mathf.Lerp(a.autumnColor, b.autumnColor, t),
                    blossoms = Mathf.Lerp(a.blossoms, b.blossoms, t),
                    leafDissolve = Mathf.Lerp(a.leafDissolve, b.leafDissolve, t),
                    snow = Mathf.Lerp(a.snow, b.snow, t),
                    windStrength = Mathf.Lerp(a.windStrength, b.windStrength, t),
                    windSpeed = Mathf.Lerp(a.windSpeed, b.windSpeed, t),
                    leafFlutter = Mathf.Lerp(a.leafFlutter, b.leafFlutter, t),
                    fallingLeaves = t < 0.5f ? a.fallingLeaves : b.fallingLeaves,
                };
            }
        }

        [Header("Season")]
        [Tooltip("Change this in the Inspector (also during Play mode) to switch seasons.")]
        [SerializeField] private Season season = Season.Spring;
        [Tooltip("Seconds for a full transition between two seasons.")]
        [SerializeField, Min(0f)] private float transitionDuration = 8f;
        [Tooltip("Autumn leaves start falling once the transition into Autumn is this far along (0..1).")]
        [SerializeField, Range(0f, 1f)] private float leavesStartFallingAt = 0.5f;

        [Header("Keyboard (Play mode)")]
#if ENABLE_INPUT_SYSTEM
        [SerializeField] private Key nextSeasonKey = Key.N;
        [SerializeField] private Key springKey = Key.Digit1;
        [SerializeField] private Key autumnKey = Key.Digit2;
        [SerializeField] private Key winterKey = Key.Digit3;
#else
        [SerializeField] private KeyCode nextSeasonKey = KeyCode.N;
        [SerializeField] private KeyCode springKey = KeyCode.Alpha1;
        [SerializeField] private KeyCode autumnKey = KeyCode.Alpha2;
        [SerializeField] private KeyCode winterKey = KeyCode.Alpha3;
#endif

        [Header("Wind")]
        [Tooltip("World-space direction the wind blows towards (Y is ignored).")]
        [SerializeField] private Vector3 windDirection = new Vector3(1f, 0f, 0.3f);

        [Header("Season Settings")]
        [SerializeField] private SeasonSettings spring = new SeasonSettings
        {
            autumnColor = 0f, blossoms = 0.6f, leafDissolve = 0f, snow = 0f,
            windStrength = 0.06f, windSpeed = 1f, leafFlutter = 0.015f, fallingLeaves = false
        };
        [SerializeField] private SeasonSettings autumn = new SeasonSettings
        {
            autumnColor = 1f, blossoms = 0f, leafDissolve = 0f, snow = 0f,
            windStrength = 0.12f, windSpeed = 1.5f, leafFlutter = 0.03f, fallingLeaves = true
        };
        [SerializeField] private SeasonSettings winter = new SeasonSettings
        {
            autumnColor = 1f, blossoms = 0f, leafDissolve = 1f, snow = 1f,
            windStrength = 0.05f, windSpeed = 1.2f, leafFlutter = 0f, fallingLeaves = false
        };

        // Global shader property IDs (must match SeasonalTreeCommon.hlsl).
        private static readonly int AutumnBlendId = Shader.PropertyToID("_TS_AutumnBlend");
        private static readonly int BlossomAmountId = Shader.PropertyToID("_TS_BlossomAmount");
        private static readonly int LeafDissolveId = Shader.PropertyToID("_TS_LeafDissolve");
        private static readonly int SnowAmountId = Shader.PropertyToID("_TS_SnowAmount");
        private static readonly int WindStrengthId = Shader.PropertyToID("_TS_WindStrength");
        private static readonly int WindSpeedId = Shader.PropertyToID("_TS_WindSpeed");
        private static readonly int FlutterStrengthId = Shader.PropertyToID("_TS_FlutterStrength");
        private static readonly int WindDirectionId = Shader.PropertyToID("_TS_WindDirection");

        private SeasonSettings current;   // values currently on the GPU
        private SeasonSettings from;      // start of the running transition
        private Season targetSeason;      // season the running transition is heading to
        private float progress = 1f;      // 0..1, 1 = no transition running
        private bool initialized;

        /// <summary>The season currently selected (the transition may still be running).</summary>
        public Season CurrentSeason => season;

        /// <summary>True while a transition is in progress.</summary>
        public bool IsTransitioning => progress < 1f;

        /// <summary>Raised when a transition to a new season starts.</summary>
        public event Action<Season> SeasonChanged;

        private void OnEnable()
        {
            // Start fully in the selected season (no transition on load).
            targetSeason = season;
            current = GetSettings(season);
            progress = 1f;
            initialized = true;
            ApplyToShaders(current);
            ApplyToParticles(current.fallingLeaves);
        }

        private void OnValidate()
        {
            // In Edit mode, preview Inspector edits immediately; in Play mode Update() picks up the change.
            if (initialized && !Application.isPlaying)
            {
                targetSeason = season;
                current = GetSettings(season);
                progress = 1f;
                ApplyToShaders(current);
            }
        }

        /// <summary>Switch to a season. instant = skip the smooth transition.</summary>
        public void SetSeason(Season newSeason, bool instant = false)
        {
            season = newSeason;
            BeginTransition(newSeason, instant || !Application.isPlaying);
        }

        /// <summary>Spring → Autumn → Winter → Spring.</summary>
        public void NextSeason()
        {
            SetSeason((Season)(((int)season + 1) % 3));
        }

        private void Update()
        {
            if (Application.isPlaying)
            {
                HandleKeyboard();
            }

            // Inspector change (or SetSeason) → start a transition towards the new season.
            if (season != targetSeason)
            {
                BeginTransition(season, !Application.isPlaying);
            }

            if (progress < 1f)
            {
                progress = transitionDuration > 0f
                    ? Mathf.Clamp01(progress + Time.deltaTime / transitionDuration)
                    : 1f;
                // SmoothStep eases in and out, so seasons don't start or stop abruptly.
                current = SeasonSettings.Lerp(from, GetSettings(targetSeason), Mathf.SmoothStep(0f, 1f, progress));

                // Leaves fall only once autumn is well under way; stop as soon as we leave it.
                bool falling = GetSettings(targetSeason).fallingLeaves && progress >= leavesStartFallingAt;
                ApplyToParticles(falling);
            }

            // Re-applied every frame: cheap, and keeps the globals right after domain reloads,
            // scene loads or other scripts touching them.
            ApplyToShaders(current);
        }

        private void BeginTransition(Season newSeason, bool instant)
        {
            targetSeason = newSeason;
            from = current;

            // Leaves that are completely gone are invisible, so jump their colour to the target
            // right away. Otherwise Winter → Spring would regrow orange leaves that then turn green.
            if (from.leafDissolve >= 0.999f)
            {
                SeasonSettings target = GetSettings(newSeason);
                from.autumnColor = target.autumnColor;
                from.blossoms = target.blossoms;
            }

            progress = instant ? 1f : 0f;
            if (instant)
            {
                current = GetSettings(newSeason);
                ApplyToParticles(current.fallingLeaves);
            }
            else if (!GetSettings(newSeason).fallingLeaves)
            {
                ApplyToParticles(false);
            }
            SeasonChanged?.Invoke(newSeason);
        }

        private SeasonSettings GetSettings(Season s)
        {
            switch (s)
            {
                case Season.Autumn: return autumn;
                case Season.Winter: return winter;
                default: return spring;
            }
        }

        private void ApplyToShaders(SeasonSettings s)
        {
            Shader.SetGlobalFloat(AutumnBlendId, s.autumnColor);
            Shader.SetGlobalFloat(BlossomAmountId, s.blossoms);
            Shader.SetGlobalFloat(LeafDissolveId, s.leafDissolve);
            Shader.SetGlobalFloat(SnowAmountId, s.snow);
            Shader.SetGlobalFloat(WindStrengthId, s.windStrength);
            Shader.SetGlobalFloat(WindSpeedId, s.windSpeed);
            Shader.SetGlobalFloat(FlutterStrengthId, s.leafFlutter);
            Shader.SetGlobalVector(WindDirectionId, windDirection);
        }

        private static void ApplyToParticles(bool falling)
        {
            // Only drive particles in Play mode; in Edit mode they would simulate in the Scene view.
            if (!Application.isPlaying)
            {
                return;
            }
            foreach (LeafCarpet carpet in LeafCarpet.All)
            {
                carpet.SetFalling(falling);
            }
        }

        private void HandleKeyboard()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            if (keyboard == null) return;
            if (keyboard[nextSeasonKey].wasPressedThisFrame) NextSeason();
            else if (keyboard[springKey].wasPressedThisFrame) SetSeason(Season.Spring);
            else if (keyboard[autumnKey].wasPressedThisFrame) SetSeason(Season.Autumn);
            else if (keyboard[winterKey].wasPressedThisFrame) SetSeason(Season.Winter);
#else
            if (Input.GetKeyDown(nextSeasonKey)) NextSeason();
            else if (Input.GetKeyDown(springKey)) SetSeason(Season.Spring);
            else if (Input.GetKeyDown(autumnKey)) SetSeason(Season.Autumn);
            else if (Input.GetKeyDown(winterKey)) SetSeason(Season.Winter);
#endif
        }
    }
}
