using System.Collections.Generic;
using UnityEngine;

namespace SeasonalTrees
{
    /// <summary>
    /// Makes falling-leaf particles stay on the ground after they land, forming a leaf carpet.
    ///
    /// The Collision module (Dampen 1, Bounce 0) stops a leaf on impact, but the Noise and Rotation
    /// modules would keep pushing and spinning it. This script detects each landing from the
    /// collision events, then pins the leaf flat on the ground for <see cref="carpetSeconds"/>
    /// and shrinks it away at the end.
    ///
    /// Requirements (see README): on the same GameObject as the Particle System; Collision module →
    /// "Send Collision Messages" ticked; Simulation Space = World.
    /// </summary>
    [RequireComponent(typeof(ParticleSystem))]
    public class LeafCarpet : MonoBehaviour
    {
        /// <summary>All active leaf systems; SeasonManager turns them on and off.</summary>
        public static readonly List<LeafCarpet> All = new List<LeafCarpet>();

        [Tooltip("Seconds a landed leaf stays on the ground.")]
        [SerializeField, Min(0.1f)] private float carpetSeconds = 30f;
        [Tooltip("Landed leaves shrink away during the last seconds of their time on the ground.")]
        [SerializeField, Min(0f)] private float shrinkSeconds = 3f;
        [Tooltip("Lift above the hit point so leaves don't z-fight with the ground (metres).")]
        [SerializeField, Min(0f)] private float groundOffset = 0.01f;
        [Tooltip("Max distance between a collision point and a particle to count as that particle's landing.")]
        [SerializeField, Min(0.01f)] private float matchRadius = 0.35f;
        [Tooltip("Random tilt of landed leaves in degrees, so the carpet doesn't look perfectly flat.")]
        [SerializeField, Range(0f, 30f)] private float landedTilt = 8f;

        private struct LandedLeaf
        {
            public Vector3 position;
            public Vector3 rotation;   // Euler degrees (particle rotation3D)
            public float size;
            public int lastSeenFrame;
        }

        private ParticleSystem ps;
        private ParticleSystem.Particle[] particles;
        private readonly List<ParticleCollisionEvent> collisionEvents = new List<ParticleCollisionEvent>();
        private readonly List<Vector3> pendingHits = new List<Vector3>();
        // Keyed by the particle's randomSeed, which stays constant for its whole life.
        private readonly Dictionary<uint, LandedLeaf> landed = new Dictionary<uint, LandedLeaf>();
        private readonly List<uint> staleKeys = new List<uint>();

        private void Awake()
        {
            ps = GetComponent<ParticleSystem>();
        }

        private void OnEnable()
        {
            if (!All.Contains(this)) All.Add(this);
        }

        private void OnDisable()
        {
            All.Remove(this);
        }

        /// <summary>Start or stop emitting. Leaves already on the ground stay until their time runs out.</summary>
        public void SetFalling(bool falling)
        {
            if (ps == null) ps = GetComponent<ParticleSystem>();
            if (falling)
            {
                if (!ps.isEmitting) ps.Play(true);
            }
            else if (ps.isEmitting)
            {
                ps.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            }
        }

        private void OnParticleCollision(GameObject other)
        {
            int count = ps.GetCollisionEvents(other, collisionEvents);
            for (int i = 0; i < count; i++)
            {
                pendingHits.Add(collisionEvents[i].intersection + collisionEvents[i].normal * groundOffset);
            }
        }

        private void LateUpdate()
        {
            int count = ps.particleCount;
            if (count == 0)
            {
                pendingHits.Clear();
                landed.Clear();
                return;
            }
            if (particles == null || particles.Length < ps.main.maxParticles)
            {
                particles = new ParticleSystem.Particle[ps.main.maxParticles];
            }
            count = ps.GetParticles(particles, count);
            int frame = Time.frameCount;

            for (int i = 0; i < count; i++)
            {
                ref ParticleSystem.Particle p = ref particles[i];
                uint key = p.randomSeed;

                if (landed.TryGetValue(key, out LandedLeaf leaf))
                {
                    // Pin the leaf: undo whatever Noise, Gravity and Rotation did this frame.
                    p.position = leaf.position;
                    p.velocity = Vector3.zero;
                    p.angularVelocity3D = Vector3.zero;
                    p.rotation3D = leaf.rotation;
                    float shrink = shrinkSeconds > 0f ? Mathf.Clamp01(p.remainingLifetime / shrinkSeconds) : 1f;
                    p.startSize = leaf.size * shrink;
                    leaf.lastSeenFrame = frame;
                    landed[key] = leaf;
                }
                else if (pendingHits.Count > 0 && TryTakeHit(p.position, Mathf.Max(matchRadius, p.GetCurrentSize(ps)), out Vector3 hit))
                {
                    // Lie flat (X = 90° turns the quad to face up) with a random yaw and slight tilt.
                    Vector3 rotation = new Vector3(
                        90f + Random.Range(-landedTilt, landedTilt),
                        Random.Range(0f, 360f),
                        Random.Range(-landedTilt, landedTilt));

                    landed[key] = new LandedLeaf
                    {
                        position = hit,
                        rotation = rotation,
                        size = p.startSize,
                        lastSeenFrame = frame,
                    };

                    // Restart the particle's clock: it now lives exactly carpetSeconds on the ground.
                    float age = p.startLifetime - p.remainingLifetime;
                    p.startLifetime = age + carpetSeconds;
                    p.remainingLifetime = carpetSeconds;
                    p.position = hit;
                    p.velocity = Vector3.zero;
                    p.angularVelocity3D = Vector3.zero;
                    p.rotation3D = rotation;
                }
            }

            ps.SetParticles(particles, count);
            pendingHits.Clear();

            // Forget leaves that have died (checked once a second).
            if (frame % 60 == 0 && landed.Count > 0)
            {
                staleKeys.Clear();
                foreach (KeyValuePair<uint, LandedLeaf> entry in landed)
                {
                    if (entry.Value.lastSeenFrame != frame) staleKeys.Add(entry.Key);
                }
                foreach (uint key in staleKeys) landed.Remove(key);
            }
        }

        // Finds (and consumes) the collision point closest to a particle, within maxDistance.
        private bool TryTakeHit(Vector3 position, float maxDistance, out Vector3 hit)
        {
            int best = -1;
            float bestSqr = maxDistance * maxDistance;
            for (int h = 0; h < pendingHits.Count; h++)
            {
                float sqr = (pendingHits[h] - position).sqrMagnitude;
                if (sqr <= bestSqr)
                {
                    bestSqr = sqr;
                    best = h;
                }
            }
            if (best < 0)
            {
                hit = default;
                return false;
            }
            hit = pendingHits[best];
            pendingHits.RemoveAt(best);
            return true;
        }
    }
}
