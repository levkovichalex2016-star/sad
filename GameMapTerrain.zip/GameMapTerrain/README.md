# Game Map – Terrain (Unity, URP)

A 512 × 512 m game map built on a flat base, with no trees:

- **Flat central plain** (6 m): open gameplay area with a spawn point at its centre
- **Mountain range** along the north / north-east edges (up to ~115 m), weathered slopes, rock on steep faces and snow on the peaks
- **Rolling foothills** in the west
- **River** flowing from the mountains into a **lake** in the south-west, with a sandy beach
- **Rocks** (~740 chipped boulders) at the foot of the mountains and along the river, tilted to the ground slope
- **Dirt road** from the south edge to the centre of the plain
- **Grass**: waving grass blades across grassy, gentle ground, in natural clumps

## Graphics

- 1024 px seamless ground textures with normal maps: grass, dirt, rock, snow
- 1025 × 1025 heightmap (twice the detail of the first version) with weathered, eroded mountains
- Rock models with the rock texture and normal map
- Glossy water with moving ripples (river flows toward the lake)
- Sunlight with soft shadows, procedural sky, sky-based ambient light and distance haze
- With URP: ACES tonemapping, bloom, colour grading, warm white balance, vignette and SMAA anti-aliasing on the Main Camera

## Install

1. Copy the `Assets/GameMap` folder into your project's `Assets` folder.
2. In Unity, choose **Tools → Game Map → Build Terrain**.

This creates a `GameMap` object in the open scene containing `Terrain`, `Rocks`, `Lake`, `River`, `PlayerSpawn`,
`PostProcessing` and (if the scene has no directional light) `Sun`. It also sets the scene's sky, ambient light and fog.
Running the command again rebuilds the map from scratch.

**For the best result:** in your URP asset, raise *Shadows → Max Distance* to about 300 and turn on *Soft Shadows*.
If the colour grading doesn't show, tick *Post Processing* on your camera.

## Customising

- **Turn off grass:** set `AddGrass = false` at the top of `Editor/GameMapBuilder.cs`, then rebuild.
- **Different textures:** replace the PNGs in `Assets/GameMap/Textures/` (keep the names), then rebuild.
- **Different rocks:** replace the models in `Assets/GameMap/Rocks/`, then rebuild.
- **Adding trees:** paint them with Unity's terrain tree brush, or add `tree,<0-2>,x,z,rotation,scale` rows to `Data/objects.csv` and rebuild (uses `Tree_763370`, `Tree_218845`, `Tree_590412` from the SeasonalTrees package).
- **A different layout:** `Tools/make_terrain.py` regenerates the data in `Data/`. Run `python make_terrain.py <output folder> <seed>`; it needs numpy, scipy and pillow. Copy the output into `Assets/GameMap/Data/` and rebuild. `gen_textures.py` and `gen_rocks.py` regenerate the textures and rocks.

## Files

| File | Contents |
|---|---|
| `Data/heightmap.raw` | 1025 × 1025 16-bit heightmap (Windows byte order). Manual import: *Terrain → Import Raw*, depth 16-bit, size 512 × 120 × 512. |
| `Data/splatmap.png` | Ground blend: R grass, G dirt/sand, B rock, A snow |
| `Data/grass_density.png` | Where grass grows (white = dense) |
| `Data/objects.csv` | Rock placements (metres) |
| `Data/map_info.json` | Map size, water level, lake, river and spawn point |
| `Textures/` | Ground textures, normal maps, water ripples, grass blade |
| `Rocks/` | Three rock models (OBJ) |
| `Editor/GameMapBuilder.cs` | The *Build Terrain* menu command |
| `Scripts/GameMapWaterFlow.cs` | Moves the water ripples |
| `Previews/` | Wide and ground-level views (rendered in Blender, without grass blades) |
