# Game Map – Terrain (Unity, URP)

A 512 × 512 m game map built on a flat base:

- **Flat central plain** (6 m height): open gameplay area with a spawn point at its centre
- **Mountain range** along the north / north-east edges, up to about 115 m, with snow on the peaks and rock on steep slopes
- **Rolling foothills** in the west
- **River** flowing from the mountains into a **lake** in the south-west, with sandy shores
- **Forests** (~4,900 trees) made from your three seasonal trees `Tree_763370`, `Tree_218845` and `Tree_590412`, plus lone trees on the plain
- **Rocks** (~740) at the foot of the mountains and along the river
- **Dirt road** from the south edge to the centre of the plain

## Install

1. Copy the `Assets/GameMap` folder into your project's `Assets` folder.
2. Make sure the tree package (`SeasonalTrees`) is imported. The builder finds the trees by name anywhere in the project.
3. In Unity, choose **Tools → Game Map → Build Terrain**.

This creates a `GameMap` object in the open scene containing:
`Terrain` (with trees painted on it), `Rocks`, `Lake`, `River` and `PlayerSpawn`.
Running the command again rebuilds the map from scratch.

## Customising

- **Ground textures:** put `Grass.png`, `Dirt.png`, `Rock.png` and `Snow.png` into `Assets/GameMap/Textures/`, then rebuild. Until then, flat colours are used.
- **Rock models:** put any rock prefabs or models into `Assets/GameMap/Rocks/`, then rebuild. Until then, simple placeholder rocks are used.
- **Seasons:** the trees keep their seasonal shaders, so `SeasonManager` switches the whole forest between Spring, Autumn and Winter.
- **A different layout:** `Tools/make_terrain.py` regenerates the data in `Data/`. Run `python make_terrain.py <output folder> <seed>`; it needs numpy, scipy and pillow. Copy the output into `Assets/GameMap/Data/` and rebuild.

## Files

| File | Contents |
|---|---|
| `Data/heightmap.raw` | 513 × 513 16-bit heightmap (Windows byte order). You can also import it manually with *Terrain → Import Raw*: depth 16-bit, size 512 × 120 × 512. |
| `Data/splatmap.png` | Ground blend: R grass, G dirt/sand, B rock, A snow |
| `Data/objects.csv` | Tree and rock placements (metres) |
| `Data/map_info.json` | Map size, water level, lake, river and spawn point |
| `Editor/GameMapBuilder.cs` | The *Build Terrain* menu command |
| `Previews/` | 3D view and top-down map |
