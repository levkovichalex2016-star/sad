"""Three irregular rock meshes as OBJ (smooth normals, box-projected UVs, flat-ish base, ~1 m radius).
Usage: python gen_rocks.py <out_dir>"""
import os
import sys

import numpy as np

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)


def icosphere(sub):
    t = (1 + 5 ** 0.5) / 2
    v = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
         (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    f = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6),
         (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10),
         (8, 6, 7), (9, 8, 1)]
    v = [np.array(p, float) / np.linalg.norm(p) for p in v]
    for _ in range(sub):
        cache, nf = {}, []

        def mid(a, b):
            k = (min(a, b), max(a, b))
            if k not in cache:
                m = v[a] + v[b]
                v.append(m / np.linalg.norm(m))
                cache[k] = len(v) - 1
            return cache[k]
        for a, b, c in f:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a)
            nf += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        f = nf
    return np.array(v), np.array(f)


def noise3(p, seed, octaves=4):
    """Sum of random sinusoids: cheap smooth 3D noise."""
    r = np.random.default_rng(seed)
    total = np.zeros(len(p))
    amp, freq = 1.0, 1.4
    for _ in range(octaves):
        for _ in range(6):
            d = r.normal(size=3)
            d /= np.linalg.norm(d)
            total += amp * np.sin(p @ d * freq + r.uniform(0, 6.28))
        amp *= 0.45
        freq *= 2.1
    return total / 6


for k in range(3):
    v, f = icosphere(3)
    r = np.random.default_rng(100 + k)
    v = v * np.array([r.uniform(1.0, 1.5), r.uniform(0.7, 1.15), r.uniform(0.8, 1.2)])   # Y is up in Unity OBJ
    v *= (1 + 0.22 * noise3(v, 10 + k))[:, None]
    # Facets: snap to a few random planes for a chipped look.
    for _ in range(14):
        n = r.normal(size=3); n /= np.linalg.norm(n)
        dist = r.uniform(0.6, 0.9)
        proj = v @ n
        over = proj > dist
        v[over] -= np.outer(proj[over] - dist, n) * 0.97
    v[:, 1] = np.maximum(v[:, 1], -0.45)          # flat base so it sits on the ground
    v[:, 1] += 0.45 - 0.12

    fn = np.cross(v[f[:, 1]] - v[f[:, 0]], v[f[:, 2]] - v[f[:, 0]])
    vn = np.zeros_like(v)
    for i in range(3):
        np.add.at(vn, f[:, i], fn)
    vn /= np.linalg.norm(vn, axis=1, keepdims=True)

    lines = [f"# Rock_{k}", f"o Rock_{k}"]
    lines += [f"v {-x:.4f} {y:.4f} {z:.4f}" for x, y, z in v]    # X mirrored: Unity flips X on OBJ import
    lines += [f"vn {-x:.4f} {y:.4f} {z:.4f}" for x, y, z in vn]
    uv_lines, face_lines, ti = [], [], 1
    for fi, (a, b, c) in enumerate(f):
        ax = np.argmax(np.abs(fn[fi]))                         # box projection on the dominant axis
        idx = [i for i in range(3) if i != ax]
        for vi in (a, b, c):
            uv_lines.append(f"vt {v[vi, idx[0]] * 0.5:.4f} {v[vi, idx[1]] * 0.5:.4f}")
        face_lines.append(f"f {c+1}/{ti+2}/{c+1} {b+1}/{ti+1}/{b+1} {a+1}/{ti}/{a+1}")   # reversed for the X mirror
        ti += 3
    open(f"{OUT}/Rock_{k}.obj", "w").write("\n".join(lines + uv_lines + face_lines) + "\n")
print("rocks written to", OUT)
