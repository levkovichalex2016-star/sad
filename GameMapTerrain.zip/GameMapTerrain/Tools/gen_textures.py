"""Seamless ground textures (albedo + OpenGL normal map) and a grass-blade billboard.
Usage: python gen_textures.py <out_dir>
Writes Grass/Dirt/Rock/Snow(.png, _Normal.png), Water_Normal.png, GrassBlade.png."""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy.spatial import cKDTree

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
N = 1024
rng = np.random.default_rng(7)
fy, fx = np.meshgrid(np.fft.fftfreq(N), np.fft.fftfreq(N), indexing="ij")
F = np.hypot(fx, fy)
F[0, 0] = 1


def spectral(beta, lo=0.0, hi=0.5, aniso=1.0):
    """Tileable 1/f^beta noise in [0,1] (built in frequency space, so it wraps perfectly)."""
    f = np.hypot(fx * aniso, fy / aniso)
    f[0, 0] = 1
    amp = f ** (-beta / 2) * ((F >= lo) & (F <= hi))
    amp[0, 0] = 0
    n = np.real(np.fft.ifft2(amp * np.exp(2j * np.pi * rng.random((N, N)))))
    return (n - n.min()) / (n.max() - n.min())


def worley(count, warp=0.0):
    """Tileable cellular noise: distance to nearest and second-nearest feature point (pixels).
    warp > 0 bends the cell borders with noise so they don't look like tiles."""
    pts = rng.random((count, 2)) * N
    tree = cKDTree(pts, boxsize=N)
    yy, xx = np.mgrid[0:N, 0:N].astype(float)
    if warp:
        yy += (spectral(2.2) - 0.5) * warp
        xx += (spectral(2.2) - 0.5) * warp
    d, _ = tree.query(np.c_[yy.ravel() + 0.5, xx.ravel() + 0.5] % N, k=2)
    return d[:, 0].reshape(N, N), d[:, 1].reshape(N, N)


def normal_map(h, strength):
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) / 2
    dy_up = (np.roll(h, 1, 0) - np.roll(h, -1, 0)) / 2
    n = np.dstack([-dx * strength, -dy_up * strength, np.ones_like(h)])
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    return Image.fromarray(np.round((n * 0.5 + 0.5) * 255).astype(np.uint8), "RGB")


def save(name, albedo, height, strength):
    Image.fromarray(np.clip(albedo * 255, 0, 255).astype(np.uint8), "RGB").save(f"{OUT}/{name}.png")
    normal_map(height, strength).save(f"{OUT}/{name}_Normal.png")


def lerp(a, b, t):
    return a + (np.asarray(b) - a) * t[..., None]


def tile_draw(draw_fn, mode, size, bg):
    """Draw with wrap-around by drawing on a 3x canvas and folding it back."""
    big = Image.new(mode, (size * 3, size * 3), bg)
    draw_fn(ImageDraw.Draw(big), size)
    a = np.asarray(big, float)
    out = np.zeros_like(a[:size, :size])
    for i in range(3):
        for j in range(3):
            out = np.maximum(out, a[i * size:(i + 1) * size, j * size:(j + 1) * size])
    return out


# --- Grass: tonal patches + thousands of short blades --------------------------------------------
macro = spectral(2.6, hi=0.02)
mid = spectral(2.0, lo=0.01, hi=0.1)


def blades(d, s):
    for _ in range(26000):
        x, y = rng.uniform(s, 2 * s, 2)
        ang = rng.normal(-np.pi / 2, 0.5)
        ln = rng.uniform(10, 26)
        v = int(rng.uniform(90, 255))
        d.line([(x, y), (x + np.cos(ang) * ln, y + np.sin(ang) * ln)], fill=v, width=int(rng.integers(2, 4)))


b = tile_draw(blades, "L", N, 0) / 255
base = lerp(np.array([0.16, 0.30, 0.07]), [0.33, 0.42, 0.12], macro)        # deep green -> yellow-green
base = lerp(base, np.array([0.22, 0.38, 0.09]), mid * 0.5)
alb = base * (0.55 + 0.6 * b[..., None])
alb = lerp(alb, np.array([0.30, 0.24, 0.13]), np.clip((0.25 - b) * 2.5, 0, 1) * 0.5)  # soil between blades
save("Grass", alb, b * 0.7 + mid * 0.3, 6)

# --- Dirt: soil + pebbles --------------------------------------------------------------------------
f1, f2 = worley(900)
peb = np.clip(1 - f1 / 9, 0, 1) ** 0.6 * (spectral(1.0) > 0.5)
soil = spectral(1.6)
alb = lerp(np.array([0.33, 0.25, 0.16]), [0.47, 0.37, 0.24], soil)
alb = lerp(alb, np.array([0.62, 0.57, 0.50]), peb * 0.75)
alb *= (0.85 + 0.3 * spectral(2.4, hi=0.03))[..., None]
save("Dirt", alb, soil * 0.4 + peb * 1.2, 10)

# --- Rock: cracked, layered stone with lichen --------------------------------------------------------
r1 = spectral(2.2)
r2 = spectral(1.6, aniso=2.5)                         # stretched -> strata
f1, f2 = worley(110, warp=90)
crack_mask = np.clip((spectral(2.0) - 0.30) * 3, 0, 1)            # cracks fade in and out
cracks = 1 - (1 - np.clip((f2 - f1) / 4, 0, 1)) * crack_mask
h = r1 * 0.6 + r2 * 0.4
h = h + spectral(1.4, lo=0.05) * 0.25                               # fine grit
strata = 0.5 + 0.5 * np.sin((np.mgrid[0:N, 0:N][0] / N * 2 * np.pi * 9) + r1 * 6)
hn = np.clip((h - np.percentile(h, 3)) / (np.percentile(h, 97) - np.percentile(h, 3)), 0, 1)
alb = lerp(np.array([0.24, 0.23, 0.22]), [0.60, 0.58, 0.54], hn)
alb = lerp(alb, np.array([0.42, 0.37, 0.31]), strata * 0.15)
alb *= (0.45 + 0.55 * cracks)[..., None]
lichen = np.clip((spectral(2.0) - 0.62) * 6, 0, 1) * (r1 > 0.5)
alb = lerp(alb, np.array([0.45, 0.47, 0.30]), lichen * 0.6)
save("Rock", alb, h * 0.8 + cracks * 0.6 + strata * 0.15, 14)

# --- Snow: soft drifts with blue shading and sparkle ------------------------------------------------
drift = spectral(2.8)
fine = spectral(1.2)
alb = lerp(np.array([0.80, 0.85, 0.93]), [0.97, 0.98, 1.0], drift)
alb += (rng.random((N, N)) > 0.997)[..., None] * 0.08
save("Snow", np.clip(alb, 0, 1), drift * 0.8 + fine * 0.1, 5)

# --- Water ripples normal map ---------------------------------------------------------------------
normal_map(spectral(2.4, lo=0.004, hi=0.08) * 0.7 + spectral(1.8, lo=0.03, hi=0.3) * 0.3, 18).save(f"{OUT}/Water_Normal.png")

# --- Grass blade billboard (RGBA, white-green; Unity tints it with healthy/dry colours) -------------
S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
for _ in range(16):
    x0 = rng.uniform(20, S - 20)
    top = rng.uniform(15, 90)
    bend = rng.uniform(-40, 40)
    w = rng.uniform(5, 9)
    pts = []
    for t in np.linspace(0, 1, 12):
        cx = x0 + bend * t * t
        cy = S - t * (S - top)
        pts.append((cx, cy, w * (1 - t) + 0.6))
    left = [(p[0] - p[2] / 2, p[1]) for p in pts]
    right = [(p[0] + p[2] / 2, p[1]) for p in pts[::-1]]
    g = int(rng.uniform(170, 235))
    d.polygon(left + right, fill=(int(g * 0.75), g, int(g * 0.45), 255))
a = np.asarray(img).astype(float)
a[..., :3] *= np.linspace(0.55, 1.0, S)[::-1, None, None] ** -0 * np.linspace(1.0, 0.6, S)[::-1, None, None]  # darker at the root
Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(f"{OUT}/GrassBlade.png")
print("textures written to", OUT)
