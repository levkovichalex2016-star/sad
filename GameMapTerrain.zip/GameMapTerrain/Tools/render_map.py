"""Render a 3D preview of the generated map with Blender (bpy). Usage: python render_map.py <data_dir> <out.png>"""
import csv, json, math, sys
import bpy, numpy as np
from PIL import Image

D, OUT = sys.argv[1], sys.argv[2]
info = json.load(open(f"{D}/map_info.json"))
RES, SIZE, H = info["heightmapResolution"], info["sizeX"], info["height"]
h = np.fromfile(f"{D}/heightmap.raw", "<u2").reshape(RES, RES) / 65535 * H
splat = np.asarray(Image.open(f"{D}/splatmap.png"), float)[::-1] / 255   # row 0 = south

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

STEP = 2
hs = h[::STEP, ::STEP]; n = hs.shape[0]; cell = SIZE / (RES - 1) * STEP
verts = [(j * cell, i * cell, hs[i, j]) for i in range(n) for j in range(n)]
faces = [(i * n + j, i * n + j + 1, (i + 1) * n + j + 1, (i + 1) * n + j) for i in range(n - 1) for j in range(n - 1)]
me = bpy.data.meshes.new("terrain"); me.from_pydata(verts, [], faces); me.update()
for p in me.polygons: p.use_smooth = True
cols = np.array([[0.20, 0.36, 0.10], [0.42, 0.32, 0.18], [0.30, 0.29, 0.27], [0.92, 0.94, 0.97]])
sp = splat[::STEP, ::STEP].reshape(-1, 4)
vc = (sp / np.maximum(sp.sum(1, keepdims=True), 1e-6)) @ cols
ca = me.color_attributes.new("col", "FLOAT_COLOR", "POINT")
for k, c in enumerate(vc): ca.data[k].color = (*c, 1)
ob = bpy.data.objects.new("terrain", me); sc.collection.objects.link(ob)
m = bpy.data.materials.new("t"); m.use_nodes = True
bs = m.node_tree.nodes["Principled BSDF"]; at = m.node_tree.nodes.new("ShaderNodeVertexColor"); at.layer_name = "col"
m.node_tree.links.new(at.outputs[0], bs.inputs["Base Color"]); bs.inputs["Roughness"].default_value = 0.95
me.materials.append(m)

# Water
b = info["lakeBounds"]
bpy.ops.mesh.primitive_plane_add(size=1, location=((b["minX"] + b["maxX"]) / 2, (b["minZ"] + b["maxZ"]) / 2, info["waterLevel"]))
w = bpy.context.object; w.scale = (b["maxX"] - b["minX"] + 24, b["maxZ"] - b["minZ"] + 24, 1)
wm = bpy.data.materials.new("w"); wm.use_nodes = True
wb = wm.node_tree.nodes["Principled BSDF"]; wb.inputs["Base Color"].default_value = (0.08, 0.25, 0.42, 1); wb.inputs["Roughness"].default_value = 0.05
w.data.materials.append(wm)
rp = info["river"]["points"]; rw = info["river"]["width"] / 2
rv, rf = [], []
for k, p in enumerate(rp):
    a, c = rp[max(k - 1, 0)], rp[min(k + 1, len(rp) - 1)]
    dx, dz = c["x"] - a["x"], c["z"] - a["z"]; L = math.hypot(dx, dz) or 1
    sx, sz = -dz / L * rw, dx / L * rw
    rv += [(p["x"] - sx, p["z"] - sz, p["y"]), (p["x"] + sx, p["z"] + sz, p["y"])]
    if k: rf.append((2 * k - 2, 2 * k - 1, 2 * k + 1, 2 * k))
rm = bpy.data.meshes.new("river"); rm.from_pydata(rv, [], rf); rm.materials.append(wm)
sc.collection.objects.link(bpy.data.objects.new("river", rm))

# Trees (3 stylised variants as instanced cone+trunk) and rocks.
def mat(c):
    mm = bpy.data.materials.new("m"); mm.use_nodes = True
    mm.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (*c, 1); return mm
tree_cols = [(0.10, 0.30, 0.08), (0.18, 0.36, 0.10), (0.07, 0.24, 0.10)]
protos = []
for t in range(3):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=3.0, location=(0, 0, 6.5)) if t != 2 else bpy.ops.mesh.primitive_cone_add(radius1=3, depth=9, location=(0, 0, 6.5))
    crown = bpy.context.object; crown.data.materials.append(mat(tree_cols[t]))
    bpy.ops.mesh.primitive_cylinder_add(radius=0.35, depth=4, location=(0, 0, 2))
    tr = bpy.context.object; tr.data.materials.append(mat((0.25, 0.16, 0.08)))
    bpy.ops.object.select_all(action="DESELECT"); crown.select_set(True); tr.select_set(True)
    bpy.context.view_layer.objects.active = crown; bpy.ops.object.join()
    protos.append(crown.data); bpy.data.objects.remove(crown)
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=1); rk = bpy.context.object; rk.data.materials.append(mat((0.33, 0.32, 0.30)))
rproto = rk.data; bpy.data.objects.remove(rk)

def hat(x, z):
    j = x / SIZE * (RES - 1); i = z / SIZE * (RES - 1)
    j0, i0 = int(min(j, RES - 2)), int(min(i, RES - 2)); fj, fi = j - j0, i - i0
    return (h[i0, j0] * (1 - fj) * (1 - fi) + h[i0, j0 + 1] * fj * (1 - fi) + h[i0 + 1, j0] * (1 - fj) * fi + h[i0 + 1, j0 + 1] * fj * fi)

for r in csv.DictReader(open(f"{D}/objects.csv")):
    x, z, s, rot = float(r["x"]), float(r["z"]), float(r["scale"]), math.radians(float(r["rotation"]))
    if r["type"] == "tree":
        o = bpy.data.objects.new("t", protos[int(r["prototype"])]); o.location = (x, z, hat(x, z) - 0.3)
    else:
        o = bpy.data.objects.new("r", rproto); o.location = (x, z, hat(x, z)); s = (s * 1.1, s * 0.9, s * 0.6)
    o.rotation_euler = (0, 0, rot); o.scale = s if isinstance(s, tuple) else (s, s, s)
    sc.collection.objects.link(o)

# Lighting, sky and camera (from the south-west, looking north-east toward the mountains).
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN")); sun.data.energy = 4.0
sun.rotation_euler = (math.radians(50), math.radians(10), math.radians(-35)); sc.collection.objects.link(sun)
world = bpy.data.worlds.new("w"); sc.world = world; world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.55, 0.72, 0.95, 1); world.node_tree.nodes["Background"].inputs[1].default_value = 0.9
cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); sc.collection.objects.link(cam); sc.camera = cam
cam.location = (-150, -230, 260); cam.data.lens = 30; cam.data.clip_end = 3000
d = np.array([300, 320, 10]) - np.array(cam.location); cam.rotation_euler = (math.atan2(math.hypot(d[0], d[1]), -d[2]), 0, math.atan2(d[1], d[0]) - math.pi / 2)
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items] else "BLENDER_EEVEE"
sc.render.resolution_x, sc.render.resolution_y = 1600, 1000
sc.view_settings.view_transform = "Standard"
sc.render.filepath = OUT
bpy.ops.render.render(write_still=True)
print("rendered", OUT)
