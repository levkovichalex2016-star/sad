"""Render previews of the generated map with Blender (bpy), using the same textures and rocks as Unity.
Usage: python render_map.py <data_dir> <tex_dir> <rocks_dir> <out_prefix>
Writes <out_prefix>_wide.png and <out_prefix>_ground.png. (Terrain grass blades are not rendered here.)"""
import csv, glob, json, math, os, sys
import bpy, numpy as np
from PIL import Image

D, TEX, ROCKS, OUT = sys.argv[1:5]
info = json.load(open(f"{D}/map_info.json"))
RES, SIZE, H = info["heightmapResolution"], info["sizeX"], info["height"]
h = np.fromfile(f"{D}/heightmap.raw", "<u2").reshape(RES, RES) / 65535 * H

# ---- Bake a colour map: the four ground textures tiled at Unity's tile sizes, blended by the splat map.
CM = 4096
# Resize each channel separately: resizing RGBA directly would premultiply by alpha (= snow weight).
splat = np.dstack([np.asarray(ch.resize((CM, CM), Image.BILINEAR), np.float32)
                   for ch in Image.open(f"{D}/splatmap.png").split()]) / 255                     # top = north
splat /= np.maximum(splat.sum(2, keepdims=True), 1e-4)
colour = np.zeros((CM, CM, 3), np.float32)
for k, (name, tile) in enumerate([("Grass", 6), ("Dirt", 5), ("Rock", 14), ("Snow", 10)]):
    px = max(8, int(round(tile / SIZE * CM)))
    t = np.asarray(Image.open(f"{TEX}/{name}.png").convert("RGB").resize((px, px), Image.LANCZOS), np.float32) / 255
    reps = CM // px + 1
    colour += np.tile(t, (reps, reps, 1))[:CM, :CM] * splat[..., k:k + 1]
cm_path = os.path.abspath(f"{OUT}_colormap.png")
Image.fromarray(np.clip(colour * 255, 0, 255).astype(np.uint8)).save(cm_path)

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene


def image_mat(name, img_path, rough, uv_scale=1.0, bump=None, bump_strength=0.3, colour_tint=None):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; bs = nt.nodes["Principled BSDF"]
    bs.inputs["Roughness"].default_value = rough
    tc = nt.nodes.new("ShaderNodeTexCoord"); mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (uv_scale, uv_scale, uv_scale)
    nt.links.new(tc.outputs["UV"], mp.inputs["Vector"])
    if img_path:
        it = nt.nodes.new("ShaderNodeTexImage"); it.image = bpy.data.images.load(img_path)
        nt.links.new(mp.outputs["Vector"], it.inputs["Vector"])
        if colour_tint:
            mx = nt.nodes.new("ShaderNodeMixRGB"); mx.blend_type = "MULTIPLY"; mx.inputs[0].default_value = 1
            mx.inputs[2].default_value = (*colour_tint, 1)
            nt.links.new(it.outputs["Color"], mx.inputs[1]); nt.links.new(mx.outputs[0], bs.inputs["Base Color"])
        else:
            nt.links.new(it.outputs["Color"], bs.inputs["Base Color"])
    if bump:
        nm = nt.nodes.new("ShaderNodeTexImage"); nm.image = bpy.data.images.load(bump); nm.image.colorspace_settings.name = "Non-Color"
        nmap = nt.nodes.new("ShaderNodeNormalMap"); nmap.inputs["Strength"].default_value = bump_strength
        nt.links.new(mp.outputs["Vector"], nm.inputs["Vector"]); nt.links.new(nm.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs["Normal"], bs.inputs["Normal"])
    return m, bs


# ---- Terrain mesh (every 2nd height sample), UVs spanning the colour map.
STEP = 2
hs = h[::STEP, ::STEP]; n = hs.shape[0]; cell = SIZE / (RES - 1) * STEP
verts = [(j * cell, i * cell, hs[i, j]) for i in range(n) for j in range(n)]
faces = [(i * n + j, i * n + j + 1, (i + 1) * n + j + 1, (i + 1) * n + j) for i in range(n - 1) for j in range(n - 1)]
me = bpy.data.meshes.new("terrain"); me.from_pydata(verts, [], faces); me.update()
me.shade_smooth()
uv = me.uv_layers.new(name="UVMap")
co = np.array(verts)[:, :2] / SIZE
loops = np.zeros(len(me.loops), int); me.loops.foreach_get("vertex_index", loops)
uv.data.foreach_set("uv", co[loops].ravel())
tm, _ = image_mat("terrain", cm_path, 0.9)
me.materials.append(tm)
sc.collection.objects.link(bpy.data.objects.new("terrain", me))

# ---- Water: lake plane + river ribbon, dark and glossy with ripples.
wm, wb = image_mat("water", None, 0.04, uv_scale=6, bump=os.path.abspath(f"{TEX}/Water_Normal.png"), bump_strength=0.25)
wb.inputs["Base Color"].default_value = (0.02, 0.07, 0.10, 1)
b = info["lakeBounds"]
bpy.ops.mesh.primitive_plane_add(size=1, location=((b["minX"] + b["maxX"]) / 2, (b["minZ"] + b["maxZ"]) / 2, info["waterLevel"]))
lake = bpy.context.object; lake.scale = (b["maxX"] - b["minX"] + 24, b["maxZ"] - b["minZ"] + 24, 1); lake.data.materials.append(wm)
rp = info["river"]["points"]; rw = info["river"]["width"] / 2
rv, rf, ruv = [], [], []
for k, p in enumerate(rp):
    a, c = rp[max(k - 1, 0)], rp[min(k + 1, len(rp) - 1)]
    dx, dz = c["x"] - a["x"], c["z"] - a["z"]; L = math.hypot(dx, dz) or 1
    sx, sz = -dz / L * rw, dx / L * rw
    rv += [(p["x"] - sx, p["z"] - sz, p["y"]), (p["x"] + sx, p["z"] + sz, p["y"])]
    if k: rf.append((2 * k - 2, 2 * k - 1, 2 * k + 1, 2 * k))
rm = bpy.data.meshes.new("river"); rm.from_pydata(rv, [], rf); rm.uv_layers.new(); rm.materials.append(wm)
sc.collection.objects.link(bpy.data.objects.new("river", rm))

# ---- Rocks: the same OBJ models shipped to Unity, with the rock texture.
rock_meshes = []
for path in sorted(glob.glob(f"{ROCKS}/Rock_*.obj")):
    bpy.ops.wm.obj_import(filepath=path, forward_axis="NEGATIVE_Z", up_axis="Y")
    o = bpy.context.selected_objects[0]; rock_meshes.append(o.data); bpy.data.objects.remove(o)
rmat, _ = image_mat("rock", os.path.abspath(f"{TEX}/Rock.png"), 0.8, uv_scale=1.5,
                    bump=os.path.abspath(f"{TEX}/Rock_Normal.png"), bump_strength=0.8)
for m in rock_meshes:
    m.materials.clear(); m.materials.append(rmat); m.shade_smooth()


def hat(x, z):
    j = x / SIZE * (RES - 1); i = z / SIZE * (RES - 1)
    j0, i0 = int(min(j, RES - 2)), int(min(i, RES - 2)); fj, fi = j - j0, i - i0
    return (h[i0, j0] * (1 - fj) * (1 - fi) + h[i0, j0 + 1] * fj * (1 - fi) + h[i0 + 1, j0] * (1 - fj) * fi + h[i0 + 1, j0 + 1] * fj * fi)


for r in csv.DictReader(open(f"{D}/objects.csv")):
    if r["type"] != "rock" or not rock_meshes:
        continue
    x, z, s, rot = float(r["x"]), float(r["z"]), float(r["scale"]), math.radians(float(r["rotation"]))
    o = bpy.data.objects.new("r", rock_meshes[int(r["prototype"]) % len(rock_meshes)])
    o.location = (x, z, hat(x, z) - 0.15 * s); o.rotation_euler = (0, 0, rot); o.scale = (s, s, s)
    sc.collection.objects.link(o)

# ---- Sun, sky and haze (matching the Unity setup: afternoon sun from the south-west).
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN"))
sun.data.energy = 4.2; sun.data.color = (1.0, 0.93, 0.82); sun.data.angle = math.radians(1.5)
sun.rotation_euler = (math.radians(52), 0, math.radians(-125)); sc.collection.objects.link(sun)
world = bpy.data.worlds.new("w"); sc.world = world; world.use_nodes = True
wn = world.node_tree; bg = wn.nodes["Background"]
grad = wn.nodes.new("ShaderNodeTexGradient"); grad.gradient_type = "LINEAR"
tcw = wn.nodes.new("ShaderNodeTexCoord"); sep = wn.nodes.new("ShaderNodeSeparateXYZ")
ramp = wn.nodes.new("ShaderNodeValToRGB")
ramp.color_ramp.elements[0].position = 0.0; ramp.color_ramp.elements[0].color = (0.72, 0.80, 0.88, 1)
ramp.color_ramp.elements[1].position = 0.35; ramp.color_ramp.elements[1].color = (0.30, 0.50, 0.82, 1)
wn.links.new(tcw.outputs["Generated"], sep.inputs[0]); wn.links.new(sep.outputs["Z"], ramp.inputs["Fac"])
wn.links.new(ramp.outputs["Color"], bg.inputs["Color"]); bg.inputs["Strength"].default_value = 1.0
# Aerial perspective: thin haze in a box around the map (a world volume would swallow the sky in EEVEE).
bpy.ops.mesh.primitive_cube_add(location=(SIZE / 2, SIZE / 2, 90))
haze = bpy.context.object; haze.scale = (1400, 1400, 90)
hm = bpy.data.materials.new("haze"); hm.use_nodes = True
hm.node_tree.nodes.remove(hm.node_tree.nodes["Principled BSDF"])
vol = hm.node_tree.nodes.new("ShaderNodeVolumePrincipled")
vol.inputs["Density"].default_value = 0.00035; vol.inputs["Color"].default_value = (0.78, 0.85, 0.94, 1)
hm.node_tree.links.new(vol.outputs[0], hm.node_tree.nodes["Material Output"].inputs["Volume"])
haze.data.materials.append(hm)

engines = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in engines else "BLENDER_EEVEE"
ee = sc.eevee
for attr, val in (("volumetric_end", 2500.0), ("volumetric_tile_size", "8"), ("use_shadows", True),
                  ("shadow_ray_count", 2), ("shadow_step_count", 8), ("use_raytracing", True), ("taa_render_samples", 48)):
    if hasattr(ee, attr):
        try: setattr(ee, attr, val)
        except Exception: pass
sc.render.resolution_x, sc.render.resolution_y = 1600, 1000
sc.view_settings.view_transform = "AgX"
try: sc.view_settings.look = "AgX - Medium High Contrast"
except Exception: pass

cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); sc.collection.objects.link(cam); sc.camera = cam
cam.data.clip_end = 4000


def shoot(loc, target, lens, path):
    cam.location = loc; cam.data.lens = lens
    d = np.array(target) - np.array(loc)
    cam.rotation_euler = (math.atan2(math.hypot(d[0], d[1]), -d[2]), 0, math.atan2(d[1], d[0]) - math.pi / 2)
    sc.render.filepath = os.path.abspath(path)
    bpy.ops.render.render(write_still=True)


shoot((-150, -230, 260), (300, 320, 10), 30, f"{OUT}_wide.png")
# Eye-level-ish view from the plain toward the mountains and the river.
sp = info["spawnPoint"]
shoot((sp["x"] - 60, sp["z"] - 120, 22), (sp["x"] + 10, sp["z"] + 230, 40), 28, f"{OUT}_ground.png")
print("rendered", OUT)
