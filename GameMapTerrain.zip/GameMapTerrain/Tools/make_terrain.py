"""Procedural game map for a Unity Terrain.

Layout (512 m x 512 m, max height 120 m, X = east, Z = north):
  * flat central plain (gameplay area) with a dirt road from the south edge
  * mountain range along the north and north-east edges, snow on the peaks
  * rolling foothills in the west
  * a lake in the south-west, fed by a river coming down from the mountains
  * forests on the foothills and mountain slopes, lone trees on the plain, rocks at the mountain foot

Outputs (in <out>/):
  heightmap.raw      1025x1025, 16-bit little-endian ("Windows" byte order in Unity)
  splatmap.png       RGBA weights: R grass, G dirt/sand, B rock, A snow
  objects.csv        type,prototype,x,z,rotation,scale   (metres, terrain-local)
  map_info.json      sizes and levels used by the Unity builder
  masks.png          debug overview
Usage: python make_terrain.py <out_dir> [seed]
"""
import csv
import json
import math
import os
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

OUT = sys.argv[1]
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 2026
os.makedirs(OUT, exist_ok=True)

RES = 1025           # Unity heightmap resolution (2^n + 1)
INCLUDE_TREES = False  # the map is kept clear of trees
SIZE = 512.0         # metres
HEIGHT = 120.0       # metres at height value 1.0
PLAIN = 6.0 / HEIGHT
WATER = 4.6 / HEIGHT
rng = np.random.default_rng(SEED)

z, x = np.mgrid[0:RES, 0:RES] / (RES - 1)      # row = z (south -> north), col = x (west -> east)


def smoothstep(a, b, v):
    t = np.clip((v - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def fbm(octaves, base_cells, persistence=0.5, ridged=False, seed_offset=0):
    """Fractal value noise via cubic-upsampled random grids. Returns values in ~[0,1]."""
    r = np.random.default_rng(SEED + seed_offset)
    total = np.zeros((RES, RES))
    amp, norm = 1.0, 0.0
    cells = base_cells
    for _ in range(octaves):
        grid = r.random((cells + 3, cells + 3))
        up = ndimage.zoom(grid, (RES + 2 * RES / cells) / (cells + 3), order=3, mode="wrap")
        off = int(RES / cells)
        n = up[off:off + RES, off:off + RES]
        n = np.clip(n, 0, 1)
        if ridged:
            n = 1 - np.abs(n * 2 - 1)
            n = n * n
        total += n * amp
        norm += amp
        amp *= persistence
        cells *= 2
    return total / norm


# --- Mountains: ridged noise inside a mask along the north / north-east edges --------------
edge_n = smoothstep(0.60, 0.92, z + 0.06 * (fbm(3, 4, seed_offset=1) - 0.5))
edge_ne = smoothstep(0.55, 0.95, (x + z) * 0.62)
mountain_mask = np.clip(np.maximum(edge_n, edge_ne * 0.85), 0, 1)
ridges = ndimage.gaussian_filter(fbm(6, 3, 0.48, ridged=True, seed_offset=2), 3.0)
mountains = mountain_mask ** 1.6 * (0.2 + 0.95 * ridges)

# --- Foothills in the west -----------------------------------------------------------------
hill_mask = smoothstep(0.42, 0.05, x) * smoothstep(0.15, 0.4, z)
hills = hill_mask * 0.14 * fbm(4, 5, 0.5, seed_offset=3)

# --- Plain with tiny undulation ------------------------------------------------------------
height = PLAIN + 0.006 * (fbm(4, 8, seed_offset=4) - 0.5) + hills + mountains
# Rescale instead of clipping so peaks stay pointed (highest peak = 96 % of the height range).
height = PLAIN + (height - PLAIN) * (0.96 - PLAIN) / max(height.max() - PLAIN, 1e-6)

# Keep the central gameplay plain perfectly usable (flat, 6 m).
cx, cz = 0.55, 0.42
d_center = np.hypot(x - cx, z - cz)
flat = smoothstep(0.22, 0.12, d_center)
height = height * (1 - flat) + PLAIN * flat

# --- River: from the mountains (north-west) down to the lake --------------------------------
lake_c = np.array([0.24, 0.24])
river_pts = np.array([[0.30, 0.80], [0.27, 0.66], [0.33, 0.52], [0.26, 0.40], [0.25, 0.30]])
t = np.linspace(0, 1, 400)
# Catmull-Rom through river_pts
P = np.vstack([river_pts[0], river_pts, river_pts[-1]])
curve = []
for i in range(1, len(P) - 2):
    p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
    for s in np.linspace(0, 1, 80, endpoint=False):
        curve.append(0.5 * ((2 * p1) + (-p0 + p2) * s + (2 * p0 - 5 * p1 + 4 * p2 - p3) * s * s
                            + (-p0 + 3 * p1 - 3 * p2 + p3) * s ** 3))
curve = np.array(curve)
river_img = np.zeros((RES, RES), bool)
ci = np.clip((curve * (RES - 1)).round().astype(int), 0, RES - 1)
river_img[ci[:, 1], ci[:, 0]] = True
d_river = ndimage.distance_transform_edt(~river_img) / (RES - 1)    # in map units
river_width = 0.009
river_cut = smoothstep(river_width * 2.6, river_width * 0.6, d_river)
# The river bed follows the terrain downhill, cut 2.5 m below the local surface (below water near the lake).
bed = np.minimum(height - 2.5 / HEIGHT, np.maximum(WATER - 1.2 / HEIGHT, height - 6 / HEIGHT))
height = height * (1 - river_cut) + bed * river_cut

# --- Lake ------------------------------------------------------------------------------------
d_lake = np.hypot((x - lake_c[0]) / 1.25, z - lake_c[1]) + 0.012 * (fbm(3, 6, seed_offset=5) - 0.5) * 4
lake = smoothstep(0.105, 0.06, d_lake)
lake_bed = WATER - 5.0 / HEIGHT * smoothstep(0.08, 0.0, d_lake)
height = height * (1 - lake) + lake_bed * lake
shore = smoothstep(0.112, 0.098, d_lake) * (1 - lake) * 0.5

# --- Dirt road: south edge -> plain centre -----------------------------------------------------
road_pts = np.array([[0.62, 0.0], [0.60, 0.12], [0.56, 0.24], [0.55, 0.36]])
road_img = np.zeros((RES, RES), bool)
for a, b in zip(road_pts[:-1], road_pts[1:]):
    for s in np.linspace(0, 1, 200):
        p = a + (b - a) * s
        road_img[int(round(p[1] * (RES - 1))), int(round(p[0] * (RES - 1)))] = True
d_road = ndimage.distance_transform_edt(~road_img) / (RES - 1)
road = smoothstep(0.012, 0.005, d_road)
height = height * (1 - road * 0.7) + PLAIN * road * 0.7    # flatten under the road

height = ndimage.gaussian_filter(height, 1.0)

# Weathering: fine ridged detail on the mountains, then thermal erosion so slopes settle
# into natural scree angles instead of noisy spikes. Flat ground is below the talus angle and is untouched.
detail = fbm(4, 24, 0.5, ridged=True, seed_offset=8)
height += mountain_mask ** 2 * (detail - 0.5) * (7 / HEIGHT)
talus = np.tan(np.radians(36)) * (SIZE / (RES - 1)) / HEIGHT
for _ in range(50):
    for dz, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        diff = height - np.roll(height, (dz, dx), (0, 1))
        move = np.where(diff > talus, (diff - talus) * 0.2, 0.0)
        # No transfer across the map edges (np.roll wraps around).
        if dz == 1: move[0, :] = 0
        if dz == -1: move[-1, :] = 0
        if dx == 1: move[:, 0] = 0
        if dx == -1: move[:, -1] = 0
        height -= move
        height += np.roll(move, (-dz, -dx), (0, 1))
height = np.clip(height, 0, 1)

# --- Slope (degrees) -------------------------------------------------------------------------------
cell = SIZE / (RES - 1)
gz, gx = np.gradient(height * HEIGHT, cell)
slope = np.degrees(np.arctan(np.hypot(gx, gz)))
h_m = height * HEIGHT

# --- Splat map: R grass, G dirt/sand, B rock, A snow ------------------------------------------------
rock = smoothstep(34, 46, slope)
snow = smoothstep(78, 92, h_m + 10 * (fbm(3, 10, seed_offset=6) - 0.5)) * smoothstep(48, 32, slope)
dirt = np.maximum(np.maximum(road, shore), river_cut * smoothstep(0.03, 0.01, d_river))
dirt = np.maximum(dirt, lake * smoothstep(WATER * HEIGHT + 0.45, WATER * HEIGHT + 0.05, h_m))   # sand only at the waterline
# Variation: bare-earth patches in the grass and scree on moderately steep ground.
dirt = np.maximum(dirt, smoothstep(0.6, 0.85, fbm(3, 20, seed_offset=9)) * 0.3 * (1 - flat * 0.6))
rock = np.maximum(rock, smoothstep(24, 34, slope) * 0.6 * smoothstep(0.45, 0.6, fbm(3, 30, seed_offset=10)))
grass = np.ones_like(height)
w = np.stack([grass, dirt * 3, rock * 4, snow * 6], -1)
w[..., 0] *= (1 - np.clip(dirt + rock + snow, 0, 1))
w = w / np.maximum(w.sum(-1, keepdims=True), 1e-6)

# --- Objects: forests, lone trees, rocks ---------------------------------------------------------
forest_noise = fbm(4, 6, 0.55, seed_offset=7)
forest = (smoothstep(0.42, 0.52, forest_noise)
          * smoothstep(36, 26, slope)
          * smoothstep(78, 62, h_m)
          * (1 - smoothstep(0.18, 0.13, d_center))
          * (h_m > WATER * HEIGHT + 1.0)
          * smoothstep(0.02, 0.035, d_road)
          * smoothstep(0.025, 0.04, d_river)
          * (1 - smoothstep(0.13, 0.11, d_lake)))
forest = np.maximum(forest, hill_mask * smoothstep(0.45, 0.55, forest_noise)
                    * smoothstep(0.02, 0.035, d_road) * (1 - lake) * smoothstep(0.025, 0.04, d_river))


def sample(arr, px, pz):
    i = np.clip(np.round(pz / SIZE * (RES - 1)).astype(int), 0, RES - 1)
    j = np.clip(np.round(px / SIZE * (RES - 1)).astype(int), 0, RES - 1)
    return arr[i, j]


objects = []
# Jittered grid; spacing ~4.5 m inside forests.
spacing = 4.5
gx_, gz_ = np.meshgrid(np.arange(spacing / 2, SIZE, spacing), np.arange(spacing / 2, SIZE, spacing))
px = gx_ + rng.uniform(-0.45, 0.45, gx_.shape) * spacing
pz = gz_ + rng.uniform(-0.45, 0.45, gz_.shape) * spacing
keep = rng.random(gx_.shape) < sample(forest, px, pz) * 0.85
for a, b in zip(px[keep], pz[keep]):
    objects.append(("tree", int(rng.integers(0, 3)), a, b, rng.uniform(0, 360), rng.uniform(0.8, 1.25)))

# A few lone trees on the plain (not in the very centre / road / water).
for _ in range(60):
    a, b = rng.uniform(20, SIZE - 20, 2)
    if (sample(h_m, a, b) < 9 and sample(d_center, a, b) > 0.08 and sample(d_road, a, b) > 0.03
            and sample(lake, a, b) < 0.01 and sample(d_river, a, b) > 0.04 and sample(slope, a, b) < 10):
        objects.append(("tree", int(rng.integers(0, 3)), a, b, rng.uniform(0, 360), rng.uniform(0.9, 1.3)))

# Rocks: mountain foot, river banks and some on the plain.
rock_zone = smoothstep(0.15, 0.4, mountain_mask) * smoothstep(60, 20, h_m) + 0.15 * smoothstep(0.05, 0.02, d_river)
for _ in range(9000):
    a, b = rng.uniform(5, SIZE - 5, 2)
    p = sample(rock_zone, a, b) * 0.35 + 0.01
    if rng.random() < p and sample(lake, a, b) < 0.01 and sample(d_road, a, b) > 0.02 and sample(river_cut, a, b) < 0.2:
        objects.append(("rock", int(rng.integers(0, 3)), a, b, rng.uniform(0, 360), rng.uniform(0.5, 2.2)))

# --- Write outputs -----------------------------------------------------------------------------
if not INCLUDE_TREES:
    objects = [o for o in objects if o[0] != "tree"]

# Grass detail density (0..1) for Unity terrain grass: on grassy, gentle, dry ground, in natural clumps.
grass_density = (w[..., 0] * smoothstep(30, 18, slope) * (h_m > WATER * HEIGHT + 0.6)
                 * (0.3 + 0.7 * smoothstep(0.35, 0.6, fbm(3, 16, seed_offset=11))))
Image.fromarray(np.round(grass_density[:-1, :-1][::-1] * 255).astype(np.uint8), "L").save(
    os.path.join(OUT, "grass_density.png"))                                       # 1024x1024, top = north

h16 = np.round(height * 65535).astype("<u2")
h16.tofile(os.path.join(OUT, "heightmap.raw"))                       # row 0 = south (z = 0)

splat = np.round(w * 255).astype(np.uint8)
Image.fromarray(splat[::-1], "RGBA").save(os.path.join(OUT, "splatmap.png"))   # image top = north

with open(os.path.join(OUT, "objects.csv"), "w", newline="") as f:
    wr = csv.writer(f)
    wr.writerow(["type", "prototype", "x", "z", "rotation", "scale"])
    for o in objects:
        wr.writerow([o[0], o[1], f"{o[2]:.2f}", f"{o[3]:.2f}", f"{o[4]:.1f}", f"{o[5]:.2f}"])

lake_cells = lake > 0.5
lz, lx = np.nonzero(lake_cells)
info = {
    "heightmapResolution": RES, "sizeX": SIZE, "sizeZ": SIZE, "height": HEIGHT,
    "waterLevel": WATER * HEIGHT,
    "lakeBounds": {"minX": float(lx.min() * cell), "maxX": float(lx.max() * cell),
                   "minZ": float(lz.min() * cell), "maxZ": float(lz.max() * cell)},
    "spawnPoint": {"x": cx * SIZE, "y": PLAIN * HEIGHT, "z": cz * SIZE},
    "counts": {"trees": sum(o[0] == "tree" for o in objects), "rocks": sum(o[0] == "rock" for o in objects)},
    "seed": SEED,
}
json.dump(info, open(os.path.join(OUT, "map_info.json"), "w"), indent=2)

# Debug overview: shaded relief coloured by splat, with objects.
light = np.clip(0.55 + 0.45 * (-gx * 0.6 + gz * 0.8) / np.maximum(np.hypot(gx, gz), 1e-6) * np.sin(np.radians(slope)) * 3, 0.3, 1.2)
cols = np.array([[96, 160, 62], [170, 140, 95], [125, 120, 112], [240, 244, 250]], float)
img = (w @ cols) * light[..., None]
img[lake > 0.5] = [70, 130, 190]
img[(river_cut > 0.5) & (d_river < river_width)] = [80, 140, 200]
img = np.clip(img, 0, 255).astype(np.uint8)
ov = Image.fromarray(img[::-1])
px_ = ov.load()
for o in objects:
    j = int(o[2] / SIZE * (RES - 1)); i = RES - 1 - int(o[3] / SIZE * (RES - 1))
    c = (28, 80, 28) if o[0] == "tree" else (60, 60, 60)
    for dj in (0, 1):
        for di in (0, 1):
            if 0 <= j + dj < RES and 0 <= i + di < RES:
                px_[j + dj, i + di] = c
ov.save(os.path.join(OUT, "masks.png"))

print(json.dumps(info, indent=2))
print(f"height range {h_m.min():.1f}..{h_m.max():.1f} m, plain {PLAIN*HEIGHT:.1f} m, water {WATER*HEIGHT:.1f} m")

# --- River water ribbon for Unity: centreline points with water-surface height and width ---------
river_pts_out = []
for p in curve[::4]:
    i = int(round(p[1] * (RES - 1))); j = int(round(p[0] * (RES - 1)))
    # Water surface: a little above the local bed, never below the lake level.
    y = max(float(height[i, j] * HEIGHT) + 0.9, WATER * HEIGHT)
    river_pts_out.append({"x": float(p[0] * SIZE), "z": float(p[1] * SIZE), "y": round(y, 2)})
# Water must only flow downhill toward the lake.
for k in range(len(river_pts_out) - 2, -1, -1):
    river_pts_out[k]["y"] = max(river_pts_out[k]["y"], river_pts_out[k + 1]["y"])
info["river"] = {"width": river_width * SIZE * 2.2, "points": river_pts_out}
json.dump(info, open(os.path.join(OUT, "map_info.json"), "w"), indent=2)
print("river points", len(river_pts_out), "y range", river_pts_out[-1]["y"], "..", river_pts_out[0]["y"])
