// Builds the game map terrain from the generated data in Assets/GameMap/Data.
// Menu: Tools > Game Map > Build Terrain
#if UNITY_EDITOR
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
#if GAMEMAP_URP
using UnityEngine.Rendering.Universal;
#endif

public static class GameMapBuilder
{
    const string Root = "Assets/GameMap";
    const string DataDir = Root + "/Data";
    const string TexDir = Root + "/Textures";
    const string GenDir = Root + "/Generated";

    // Set to false to build the map without terrain grass.
    const bool AddGrass = true;

    [System.Serializable] class P3 { public float x, y, z; }
    [System.Serializable] class River { public float width; public P3[] points; }
    [System.Serializable] class Bounds2 { public float minX, maxX, minZ, maxZ; }
    [System.Serializable]
    class MapInfo
    {
        public int heightmapResolution;
        public float sizeX, sizeZ, height, waterLevel;
        public Bounds2 lakeBounds;
        public P3 spawnPoint;
        public River river;
    }

    [MenuItem("Tools/Game Map/Build Terrain")]
    public static void Build()
    {
        var info = JsonUtility.FromJson<MapInfo>(File.ReadAllText(DataDir + "/map_info.json"));
        int res = info.heightmapResolution;
        if (!AssetDatabase.IsValidFolder(GenDir)) AssetDatabase.CreateFolder(Root, "Generated");
        PrepareTextureImports();

        // Terrain data + heights (16-bit little-endian, row 0 = south edge).
        var td = new TerrainData { heightmapResolution = res };
        td.size = new Vector3(info.sizeX, info.height, info.sizeZ);
        byte[] raw = File.ReadAllBytes(DataDir + "/heightmap.raw");
        var h = new float[res, res];
        for (int z = 0; z < res; z++)
            for (int x = 0; x < res; x++)
            {
                int i = (z * res + x) * 2;
                h[z, x] = (raw[i] | (raw[i + 1] << 8)) / 65535f;
            }
        td.SetHeights(0, 0, h);

        td.alphamapResolution = 1024;
        td.terrainLayers = new[]
        {
            MakeLayer("Grass", new Color(0.30f, 0.45f, 0.15f), 6, 0.05f, 1.0f),
            MakeLayer("Dirt",  new Color(0.42f, 0.33f, 0.22f), 5, 0.05f, 1.0f),
            MakeLayer("Rock",  new Color(0.45f, 0.44f, 0.42f), 14, 0.15f, 1.2f),
            MakeLayer("Snow",  new Color(0.92f, 0.94f, 0.98f), 10, 0.35f, 0.6f),
        };
        ApplySplat(td);
        if (AddGrass) ApplyGrass(td);

        // Trees: the three seasonal trees, only when objects.csv contains trees.
        var treeProtos = new List<TreePrototype>();
        bool hasTrees = File.ReadAllText(DataDir + "/objects.csv").Contains("\ntree,");
        if (hasTrees)
            foreach (var n in new[] { "Tree_763370", "Tree_218845", "Tree_590412" })
            {
                var prefab = FindPrefab(n);
                if (prefab != null) treeProtos.Add(new TreePrototype { prefab = prefab });
                else Debug.LogWarning("GameMap: tree model '" + n + "' not found; its trees are skipped.");
            }
        td.treePrototypes = treeProtos.ToArray();

        AssetDatabase.DeleteAsset(GenDir + "/GameMapTerrain.asset");
        AssetDatabase.CreateAsset(td, GenDir + "/GameMapTerrain.asset");

        var old = GameObject.Find("GameMap");
        if (old != null) Object.DestroyImmediate(old);
        var map = new GameObject("GameMap");
        var terrainGo = Terrain.CreateTerrainGameObject(td);
        terrainGo.name = "Terrain";
        terrainGo.transform.SetParent(map.transform, false);
        var terrain = terrainGo.GetComponent<Terrain>();
        terrain.heightmapPixelError = 3;          // sharper distant mountains
        terrain.basemapDistance = 1000;           // full-detail ground textures across the map
        terrain.drawInstanced = true;
        terrain.treeBillboardDistance = 120;
        terrain.treeDistance = 600;
        terrain.detailObjectDistance = 110;
        terrain.detailObjectDensity = 1f;
        terrain.shadowCastingMode = ShadowCastingMode.On;

        PlaceObjects(td, info, treeProtos.Count, map.transform);
        terrain.Flush();

        BuildWater(info, map.transform);
        SetupAtmosphere(map.transform);

        var spawn = new GameObject("PlayerSpawn");
        spawn.transform.SetParent(map.transform, false);
        spawn.transform.position = new Vector3(info.spawnPoint.x, info.spawnPoint.y + 1f, info.spawnPoint.z);

        AssetDatabase.SaveAssets();
        Selection.activeGameObject = map;
        Debug.Log("GameMap: terrain built.");
    }

    // ---------------------------------------------------------------- textures

    static void PrepareTextureImports()
    {
        foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { TexDir }))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) continue;
            bool changed = false;
            bool isNormal = path.EndsWith("_Normal.png");
            bool isBlade = path.EndsWith("GrassBlade.png");
            if (isNormal && imp.textureType != TextureImporterType.NormalMap) { imp.textureType = TextureImporterType.NormalMap; changed = true; }
            if (isBlade && !imp.alphaIsTransparency)
            {
                imp.alphaIsTransparency = true;
                imp.wrapMode = TextureWrapMode.Clamp;
                changed = true;
            }
            if (!isBlade && imp.wrapMode != TextureWrapMode.Repeat) { imp.wrapMode = TextureWrapMode.Repeat; changed = true; }
            if (imp.anisoLevel < 8) { imp.anisoLevel = 8; changed = true; }   // crisp ground at grazing angles
            if (changed) imp.SaveAndReimport();
        }
    }

    static Texture2D LoadTex(string name) => AssetDatabase.LoadAssetAtPath<Texture2D>(TexDir + "/" + name + ".png");

    static TerrainLayer MakeLayer(string name, Color tint, float tile, float smoothness, float normalScale)
    {
        string path = GenDir + "/Layer_" + name + ".terrainlayer";
        var layer = new TerrainLayer();
        var tex = LoadTex(name);
        if (tex == null) tex = SolidTexture("Tint_" + name, tint);   // fallback when textures are missing
        layer.diffuseTexture = tex;
        layer.normalMapTexture = LoadTex(name + "_Normal");
        layer.normalScale = normalScale;
        layer.smoothness = smoothness;
        layer.tileSize = new Vector2(tile, tile);
        AssetDatabase.DeleteAsset(path);
        AssetDatabase.CreateAsset(layer, path);
        return layer;
    }

    static Texture2D SolidTexture(string name, Color c)
    {
        var tex = new Texture2D(4, 4);
        var px = new Color[16];
        for (int i = 0; i < 16; i++) px[i] = c;
        tex.SetPixels(px);
        tex.Apply();
        string texPath = GenDir + "/" + name + ".png";
        File.WriteAllBytes(texPath, tex.EncodeToPNG());
        AssetDatabase.ImportAsset(texPath);
        return AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
    }

    static Texture2D ReadPng(string path)
    {
        var img = new Texture2D(2, 2);
        img.LoadImage(File.ReadAllBytes(path));   // PNG bottom row = south
        return img;
    }

    static void ApplySplat(TerrainData td)
    {
        var img = ReadPng(DataDir + "/splatmap.png");
        int w = td.alphamapResolution;
        var a = new float[w, w, 4];
        for (int z = 0; z < w; z++)
            for (int x = 0; x < w; x++)
            {
                Color c = img.GetPixelBilinear((x + 0.5f) / w, (z + 0.5f) / w);
                float s = Mathf.Max(c.r + c.g + c.b + c.a, 1e-4f);
                a[z, x, 0] = c.r / s; a[z, x, 1] = c.g / s; a[z, x, 2] = c.b / s; a[z, x, 3] = c.a / s;
            }
        td.SetAlphamaps(0, 0, a);
    }

    static void ApplyGrass(TerrainData td)
    {
        var blade = LoadTex("GrassBlade");
        string densityPath = DataDir + "/grass_density.png";
        if (blade == null || !File.Exists(densityPath)) return;

        td.SetDetailResolution(1024, 32);
        // Unity 2022.2+ defaults to coverage mode; this data is written as instance counts.
        var scatter = typeof(TerrainData).GetMethod("SetDetailScatterMode");
        if (scatter != null)
            scatter.Invoke(td, new[] { System.Enum.Parse(scatter.GetParameters()[0].ParameterType, "InstanceCountMode") });

        td.detailPrototypes = new[]
        {
            new DetailPrototype
            {
                prototypeTexture = blade,
                renderMode = DetailRenderMode.GrassBillboard,
                minWidth = 0.7f, maxWidth = 1.3f,
                minHeight = 0.45f, maxHeight = 0.9f,
                noiseSpread = 0.4f,
                healthyColor = new Color(0.55f, 0.75f, 0.32f),
                dryColor = new Color(0.78f, 0.74f, 0.42f),
            }
        };
        td.wavingGrassTint = new Color(0.75f, 0.85f, 0.6f);
        td.wavingGrassStrength = 0.35f;
        td.wavingGrassAmount = 0.35f;
        td.wavingGrassSpeed = 0.4f;

        var img = ReadPng(densityPath);
        int n = td.detailResolution;
        var d = new int[n, n];
        for (int z = 0; z < n; z++)
            for (int x = 0; x < n; x++)
                d[z, x] = Mathf.RoundToInt(img.GetPixelBilinear((x + 0.5f) / n, (z + 0.5f) / n).r * 3f);
        td.SetDetailLayer(0, 0, 0, d);
    }

    // ---------------------------------------------------------------- objects

    static void PlaceObjects(TerrainData td, MapInfo info, int treeProtoCount, Transform parent)
    {
        var rockPrefabs = new List<GameObject>();
        foreach (var guid in AssetDatabase.FindAssets("t:GameObject", new[] { Root + "/Rocks" }))
            rockPrefabs.Add(AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(guid)));
        var rocksRoot = new GameObject("Rocks").transform;
        rocksRoot.SetParent(parent, false);
        var rockMat = RockMaterial();

        var trees = new List<TreeInstance>();
        var ci = CultureInfo.InvariantCulture;
        string[] lines = File.ReadAllLines(DataDir + "/objects.csv");
        for (int i = 1; i < lines.Length; i++)
        {
            var f = lines[i].Split(',');
            if (f.Length < 6) continue;
            int proto = int.Parse(f[1], ci);
            float x = float.Parse(f[2], ci), z = float.Parse(f[3], ci);
            float rot = float.Parse(f[4], ci), scale = float.Parse(f[5], ci);
            if (f[0] == "tree")
            {
                if (treeProtoCount == 0) continue;
                trees.Add(new TreeInstance
                {
                    prototypeIndex = proto % treeProtoCount,
                    position = new Vector3(x / info.sizeX, 0, z / info.sizeZ),   // y = 0 snaps to the ground
                    rotation = rot * Mathf.Deg2Rad,
                    widthScale = scale, heightScale = scale,
                    color = Color.white, lightmapColor = Color.white,
                });
            }
            else
            {
                float y = td.GetInterpolatedHeight(x / info.sizeX, z / info.sizeZ);
                // Tilt rocks to the ground slope so they sit naturally on hillsides.
                Vector3 normal = td.GetInterpolatedNormal(x / info.sizeX, z / info.sizeZ);
                GameObject go = rockPrefabs.Count > 0
                    ? (GameObject)PrefabUtility.InstantiatePrefab(rockPrefabs[proto % rockPrefabs.Count])
                    : MakeRock(proto);
                go.transform.SetParent(rocksRoot, false);
                go.transform.position = new Vector3(x, y - 0.15f * scale, z);
                go.transform.rotation = Quaternion.FromToRotation(Vector3.up, normal) * Quaternion.Euler(0, rot, 0);
                go.transform.localScale *= scale;
                go.isStatic = true;
                foreach (var r in go.GetComponentsInChildren<Renderer>())
                {
                    r.sharedMaterial = rockMat;
                    r.shadowCastingMode = ShadowCastingMode.On;
                }
            }
        }
        td.SetTreeInstances(trees.ToArray(), true);
    }

    // Placeholder rock used when no rock models are present in Assets/GameMap/Rocks.
    static GameObject MakeRock(int variant)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Rock";
        go.transform.localScale = new Vector3(1.6f + 0.3f * variant, 0.9f + 0.2f * variant, 1.3f);
        return go;
    }

    static Shader LitShader() => Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");

    static void SetNormalMap(Material m, Texture2D normal, float strength)
    {
        if (normal == null) return;
        m.SetTexture("_BumpMap", normal);
        m.SetFloat("_BumpScale", strength);
        m.EnableKeyword("_NORMALMAP");
    }

    static Material RockMaterial()
    {
        string path = GenDir + "/Rock.mat";
        AssetDatabase.DeleteAsset(path);
        var m = new Material(LitShader()) { color = new Color(0.9f, 0.88f, 0.85f) };
        var tex = LoadTex("Rock");
        if (tex != null) { m.mainTexture = tex; m.mainTextureScale = new Vector2(1.5f, 1.5f); }
        else m.color = new Color(0.45f, 0.44f, 0.42f);
        SetNormalMap(m, LoadTex("Rock_Normal"), 1.2f);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.18f);
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", 0.18f);
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    // ---------------------------------------------------------------- water

    static Material WaterMaterial()
    {
        string path = GenDir + "/Water.mat";
        AssetDatabase.DeleteAsset(path);
        var m = new Material(LitShader());
        var col = new Color(0.07f, 0.22f, 0.30f, 0.82f);
        if (m.HasProperty("_Surface"))
        {
            // URP Lit: transparent surface.
            m.SetFloat("_Surface", 1);
            m.SetFloat("_Blend", 0);
            m.SetFloat("_Smoothness", 0.96f);
            m.SetFloat("_Metallic", 0.05f);
            m.SetOverrideTag("RenderType", "Transparent");
            m.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            m.renderQueue = (int)RenderQueue.Transparent;
        }
        m.color = col;
        var ripples = LoadTex("Water_Normal");
        SetNormalMap(m, ripples, 0.6f);
        if (ripples != null) m.SetTextureScale("_BumpMap", new Vector2(8, 8));
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    static void BuildWater(MapInfo info, Transform parent)
    {
        var mat = WaterMaterial();

        // Lake: flat plane over the lake bounds (terrain hides the parts outside the shoreline).
        var lake = GameObject.CreatePrimitive(PrimitiveType.Plane);
        lake.name = "Lake";
        Object.DestroyImmediate(lake.GetComponent<Collider>());
        var b = info.lakeBounds;
        float pad = 12f;
        lake.transform.SetParent(parent, false);
        lake.transform.position = new Vector3((b.minX + b.maxX) / 2, info.waterLevel, (b.minZ + b.maxZ) / 2);
        lake.transform.localScale = new Vector3((b.maxX - b.minX + pad * 2) / 10f, 1, (b.maxZ - b.minZ + pad * 2) / 10f);
        var lakeRenderer = lake.GetComponent<Renderer>();
        lakeRenderer.sharedMaterial = mat;
        lakeRenderer.shadowCastingMode = ShadowCastingMode.Off;
        lake.AddComponent<GameMapWaterFlow>().speed = new Vector2(0.004f, 0.002f);

        // River: ribbon mesh along the centreline, sloping down toward the lake.
        var pts = info.river.points;
        if (pts == null || pts.Length < 2) return;
        var verts = new Vector3[pts.Length * 2];
        var uvs = new Vector2[pts.Length * 2];
        var tris = new int[(pts.Length - 1) * 6];
        float half = info.river.width / 2, dist = 0;
        for (int i = 0; i < pts.Length; i++)
        {
            var p = new Vector3(pts[i].x, pts[i].y, pts[i].z);
            var a = new Vector3(pts[Mathf.Max(i - 1, 0)].x, 0, pts[Mathf.Max(i - 1, 0)].z);
            var c = new Vector3(pts[Mathf.Min(i + 1, pts.Length - 1)].x, 0, pts[Mathf.Min(i + 1, pts.Length - 1)].z);
            var dir = (c - a).normalized;
            var side = new Vector3(-dir.z, 0, dir.x) * half;
            if (i > 0) dist += Vector3.Distance(new Vector3(pts[i - 1].x, pts[i - 1].y, pts[i - 1].z), p);
            verts[i * 2] = p - side; verts[i * 2 + 1] = p + side;
            uvs[i * 2] = new Vector2(0, dist / 10f); uvs[i * 2 + 1] = new Vector2(1, dist / 10f);
            if (i < pts.Length - 1)
            {
                int t = i * 6, v = i * 2;
                tris[t] = v; tris[t + 1] = v + 2; tris[t + 2] = v + 1;
                tris[t + 3] = v + 1; tris[t + 4] = v + 2; tris[t + 5] = v + 3;
            }
        }
        var mesh = new Mesh { name = "RiverMesh", vertices = verts, uv = uvs, triangles = tris };
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        AssetDatabase.DeleteAsset(GenDir + "/RiverMesh.asset");
        AssetDatabase.CreateAsset(mesh, GenDir + "/RiverMesh.asset");
        var river = new GameObject("River", typeof(MeshFilter), typeof(MeshRenderer));
        river.transform.SetParent(parent, false);
        river.GetComponent<MeshFilter>().sharedMesh = mesh;
        var rr = river.GetComponent<MeshRenderer>();
        rr.sharedMaterial = mat;
        rr.shadowCastingMode = ShadowCastingMode.Off;
        river.AddComponent<GameMapWaterFlow>().speed = new Vector2(0f, -0.06f);   // flows downhill (toward the lake)
    }

    // ---------------------------------------------------------------- sky, sun, fog, post-processing

    static void SetupAtmosphere(Transform parent)
    {
        // Sun: reuse the scene's directional light if there is one.
        Light sun = null;
        foreach (var l in Object.FindObjectsOfType<Light>())
            if (l.type == LightType.Directional) { sun = l; break; }
        if (sun == null)
        {
            var go = new GameObject("Sun");
            go.transform.SetParent(parent, false);
            sun = go.AddComponent<Light>();
            sun.type = LightType.Directional;
        }
        sun.transform.rotation = Quaternion.Euler(38f, -35f, 0f);    // afternoon sun from the south-west
        sun.color = new Color(1f, 0.93f, 0.82f);
        sun.intensity = 1.35f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = 0.85f;

        string skyPath = GenDir + "/Sky.mat";
        AssetDatabase.DeleteAsset(skyPath);
        var sky = new Material(Shader.Find("Skybox/Procedural"));
        sky.SetFloat("_SunSize", 0.035f);
        sky.SetFloat("_AtmosphereThickness", 0.9f);
        sky.SetColor("_SkyTint", new Color(0.45f, 0.55f, 0.7f));
        sky.SetColor("_GroundColor", new Color(0.36f, 0.38f, 0.36f));
        sky.SetFloat("_Exposure", 1.25f);
        AssetDatabase.CreateAsset(sky, skyPath);

        RenderSettings.skybox = sky;
        RenderSettings.sun = sun;
        RenderSettings.ambientMode = AmbientMode.Skybox;
        RenderSettings.ambientIntensity = 1.0f;
        RenderSettings.defaultReflectionMode = DefaultReflectionMode.Skybox;
        // Distance haze that matches the horizon colour, gives the mountains depth.
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = new Color(0.70f, 0.78f, 0.86f);
        RenderSettings.fogStartDistance = 120f;
        RenderSettings.fogEndDistance = 1300f;
        DynamicGI.UpdateEnvironment();

        SetupPostProcessing(parent);
    }

    static void SetupPostProcessing(Transform parent)
    {
#if GAMEMAP_URP
        string path = GenDir + "/GameMapPostFX.asset";
        AssetDatabase.DeleteAsset(path);
        var profile = ScriptableObject.CreateInstance<VolumeProfile>();
        AssetDatabase.CreateAsset(profile, path);

        var tone = profile.Add<Tonemapping>(true);
        tone.mode.Override(TonemappingMode.ACES);
        var bloom = profile.Add<Bloom>(true);
        bloom.threshold.Override(1.0f);
        bloom.intensity.Override(0.45f);
        bloom.scatter.Override(0.65f);
        var color = profile.Add<ColorAdjustments>(true);
        color.postExposure.Override(0.25f);
        color.contrast.Override(12f);
        color.saturation.Override(12f);
        var wb = profile.Add<WhiteBalance>(true);
        wb.temperature.Override(6f);
        var vignette = profile.Add<Vignette>(true);
        vignette.intensity.Override(0.22f);
        vignette.smoothness.Override(0.45f);
        // Volume components must be saved inside the profile asset.
        foreach (var c in profile.components) { c.hideFlags = HideFlags.HideInInspector | HideFlags.HideInHierarchy; AssetDatabase.AddObjectToAsset(c, profile); }
        EditorUtility.SetDirty(profile);

        var volGo = new GameObject("PostProcessing");
        volGo.transform.SetParent(parent, false);
        var vol = volGo.AddComponent<Volume>();
        vol.isGlobal = true;
        vol.sharedProfile = profile;

        var cam = Camera.main;
        if (cam != null)
        {
            var data = cam.GetUniversalAdditionalCameraData();
            data.renderPostProcessing = true;
            data.antialiasing = AntialiasingMode.SubpixelMorphologicalAntiAliasing;
            data.renderShadows = true;
            cam.farClipPlane = Mathf.Max(cam.farClipPlane, 2000f);
        }
        else Debug.Log("GameMap: no Main Camera found; enable Post Processing on your camera to see the colour grading.");
#else
        Debug.Log("GameMap: URP not detected, so post-processing (tonemapping, bloom, colour grading) was skipped.");
#endif
    }

    static GameObject FindPrefab(string name)
    {
        foreach (var guid in AssetDatabase.FindAssets(name + " t:GameObject"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (Path.GetFileNameWithoutExtension(path) == name)
                return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }
        return null;
    }
}
#endif
