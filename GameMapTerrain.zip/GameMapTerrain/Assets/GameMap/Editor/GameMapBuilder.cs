// Builds the game map terrain from the generated data in Assets/GameMap/Data.
// Menu: Tools > Game Map > Build Terrain
#if UNITY_EDITOR
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

public static class GameMapBuilder
{
    const string Root = "Assets/GameMap";
    const string DataDir = Root + "/Data";

    [System.Serializable] class P3 { public float x, y, z; }
    [System.Serializable] class River { public float width; public P3[] points; }
    [System.Serializable] class Bounds2 { public float minX, maxX, minZ, maxZ; }
    [System.Serializable]
    class MapInfo
    {
        public int heightmapResolution;
        public float sizeX, sizeZ, height, waterLevel;
        public Bounds2 lakeBounds;
        public P3 spawnPoint;
        public River river;
    }

    [MenuItem("Tools/Game Map/Build Terrain")]
    public static void Build()
    {
        var info = JsonUtility.FromJson<MapInfo>(File.ReadAllText(DataDir + "/map_info.json"));
        int res = info.heightmapResolution;
        if (!AssetDatabase.IsValidFolder(Root + "/Generated")) AssetDatabase.CreateFolder(Root, "Generated");

        // Terrain data + heights (16-bit little-endian, row 0 = south edge).
        var td = new TerrainData { heightmapResolution = res };
        td.size = new Vector3(info.sizeX, info.height, info.sizeZ);
        byte[] raw = File.ReadAllBytes(DataDir + "/heightmap.raw");
        var h = new float[res, res];
        for (int z = 0; z < res; z++)
            for (int x = 0; x < res; x++)
            {
                int i = (z * res + x) * 2;
                h[z, x] = (raw[i] | (raw[i + 1] << 8)) / 65535f;
            }
        td.SetHeights(0, 0, h);

        // Ground layers: grass, dirt, rock, snow (textures are optional; tints keep it readable without them).
        td.terrainLayers = new[]
        {
            MakeLayer("Grass", new Color(0.38f, 0.58f, 0.25f), 8),
            MakeLayer("Dirt",  new Color(0.55f, 0.45f, 0.32f), 6),
            MakeLayer("Rock",  new Color(0.47f, 0.46f, 0.44f), 10),
            MakeLayer("Snow",  new Color(0.93f, 0.95f, 0.98f), 10),
        };
        ApplySplat(td);

        // Trees: the three seasonal trees; rocks: any prefabs found in Assets/GameMap/Rocks.
        var treeProtos = new List<TreePrototype>();
        bool hasTrees = File.ReadAllText(DataDir + "/objects.csv").Contains("\ntree,");
        if (hasTrees)
        foreach (var n in new[] { "Tree_763370", "Tree_218845", "Tree_590412" })
        {
            var prefab = FindPrefab(n);
            if (prefab != null) treeProtos.Add(new TreePrototype { prefab = prefab });
            else Debug.LogWarning("GameMap: tree model '" + n + "' not found; its trees are skipped.");
        }
        td.treePrototypes = treeProtos.ToArray();

        AssetDatabase.DeleteAsset(Root + "/Generated/GameMapTerrain.asset");
        AssetDatabase.CreateAsset(td, Root + "/Generated/GameMapTerrain.asset");

        var old = GameObject.Find("GameMap");
        if (old != null) Object.DestroyImmediate(old);
        var map = new GameObject("GameMap");
        var terrainGo = Terrain.CreateTerrainGameObject(td);
        terrainGo.name = "Terrain";
        terrainGo.transform.SetParent(map.transform, false);
        var terrain = terrainGo.GetComponent<Terrain>();
        terrain.treeBillboardDistance = 120;
        terrain.treeDistance = 600;
        terrain.basemapDistance = 600;

        PlaceObjects(td, info, treeProtos.Count, map.transform);
        terrain.Flush();

        BuildWater(info, map.transform);

        var spawn = new GameObject("PlayerSpawn");
        spawn.transform.SetParent(map.transform, false);
        spawn.transform.position = new Vector3(info.spawnPoint.x, info.spawnPoint.y + 1f, info.spawnPoint.z);

        AssetDatabase.SaveAssets();
        Selection.activeGameObject = map;
        Debug.Log("GameMap: terrain built (" + td.treeInstanceCount + " trees).");
    }

    static TerrainLayer MakeLayer(string name, Color tint, float tile)
    {
        string path = Root + "/Generated/Layer_" + name + ".terrainlayer";
        if (!AssetDatabase.IsValidFolder(Root + "/Generated")) AssetDatabase.CreateFolder(Root, "Generated");
        var layer = new TerrainLayer();
        var tex = AssetDatabase.LoadAssetAtPath<Texture2D>(Root + "/Textures/" + name + ".png");
        if (tex == null)
        {
            // Fallback: a solid-colour texture so the map renders correctly before real textures are added.
            tex = new Texture2D(4, 4);
            var px = new Color[16];
            for (int i = 0; i < 16; i++) px[i] = tint;
            tex.SetPixels(px);
            tex.Apply();
            string texPath = Root + "/Generated/Tint_" + name + ".png";
            File.WriteAllBytes(texPath, tex.EncodeToPNG());
            AssetDatabase.ImportAsset(texPath);
            tex = AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
        }
        layer.diffuseTexture = tex;
        layer.tileSize = new Vector2(tile, tile);
        AssetDatabase.DeleteAsset(path);
        AssetDatabase.CreateAsset(layer, path);
        return layer;
    }

    static void ApplySplat(TerrainData td)
    {
        var img = new Texture2D(2, 2);
        img.LoadImage(File.ReadAllBytes(DataDir + "/splatmap.png"));   // PNG bottom row = south
        int w = td.alphamapResolution;
        var a = new float[w, w, 4];
        for (int z = 0; z < w; z++)
            for (int x = 0; x < w; x++)
            {
                Color c = img.GetPixelBilinear((x + 0.5f) / w, (z + 0.5f) / w);
                float s = Mathf.Max(c.r + c.g + c.b + c.a, 1e-4f);
                a[z, x, 0] = c.r / s; a[z, x, 1] = c.g / s; a[z, x, 2] = c.b / s; a[z, x, 3] = c.a / s;
            }
        td.SetAlphamaps(0, 0, a);
    }

    static void PlaceObjects(TerrainData td, MapInfo info, int treeProtoCount, Transform parent)
    {
        var rockPrefabs = new List<GameObject>();
        foreach (var guid in AssetDatabase.FindAssets("t:GameObject", new[] { Root + "/Rocks" }))
            rockPrefabs.Add(AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(guid)));
        var rocksRoot = new GameObject("Rocks").transform;
        rocksRoot.SetParent(parent, false);

        var trees = new List<TreeInstance>();
        var ci = CultureInfo.InvariantCulture;
        string[] lines = File.ReadAllLines(DataDir + "/objects.csv");
        for (int i = 1; i < lines.Length; i++)
        {
            var f = lines[i].Split(',');
            int proto = int.Parse(f[1], ci);
            float x = float.Parse(f[2], ci), z = float.Parse(f[3], ci);
            float rot = float.Parse(f[4], ci), scale = float.Parse(f[5], ci);
            if (f[0] == "tree")
            {
                if (treeProtoCount == 0) continue;
                trees.Add(new TreeInstance
                {
                    prototypeIndex = proto % treeProtoCount,
                    position = new Vector3(x / info.sizeX, 0, z / info.sizeZ),   // y = 0 snaps to the ground
                    rotation = rot * Mathf.Deg2Rad,
                    widthScale = scale, heightScale = scale,
                    color = Color.white, lightmapColor = Color.white,
                });
            }
            else
            {
                float y = td.GetInterpolatedHeight(x / info.sizeX, z / info.sizeZ);
                GameObject go = rockPrefabs.Count > 0
                    ? (GameObject)PrefabUtility.InstantiatePrefab(rockPrefabs[proto % rockPrefabs.Count])
                    : MakeRock(proto);
                go.transform.SetParent(rocksRoot, false);
                go.transform.position = new Vector3(x, y - 0.25f * scale, z);
                go.transform.rotation = Quaternion.Euler(0, rot, 0);
                go.transform.localScale *= scale;
            }
        }
        td.SetTreeInstances(trees.ToArray(), true);
    }

    // Placeholder rock (flattened, slightly squashed sphere) used when no rock prefabs are provided.
    static GameObject MakeRock(int variant)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Rock";
        go.transform.localScale = new Vector3(1.6f + 0.3f * variant, 0.9f + 0.2f * variant, 1.3f);
        go.isStatic = true;
        var r = go.GetComponent<Renderer>();
        r.sharedMaterial = RockMaterial();
        return go;
    }

    static Material rockMat;
    static Material RockMaterial()
    {
        if (rockMat != null) return rockMat;
        string path = Root + "/Generated/Rock.mat";
        rockMat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (rockMat == null)
        {
            var sh = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            rockMat = new Material(sh) { color = new Color(0.45f, 0.44f, 0.42f) };
            AssetDatabase.CreateAsset(rockMat, path);
        }
        return rockMat;
    }

    static Material WaterMaterial()
    {
        string path = Root + "/Generated/Water.mat";
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m != null) return m;
        var sh = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        m = new Material(sh);
        var col = new Color(0.18f, 0.42f, 0.62f, 0.75f);
        // URP transparent surface.
        if (m.HasProperty("_Surface"))
        {
            m.SetFloat("_Surface", 1);
            m.SetFloat("_Smoothness", 0.92f);
            m.SetOverrideTag("RenderType", "Transparent");
            m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            m.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        }
        m.color = col;
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    static void BuildWater(MapInfo info, Transform parent)
    {
        var mat = WaterMaterial();

        // Lake: flat plane over the lake bounds (terrain hides the parts outside the shoreline).
        var lake = GameObject.CreatePrimitive(PrimitiveType.Plane);
        lake.name = "Lake";
        Object.DestroyImmediate(lake.GetComponent<Collider>());
        var b = info.lakeBounds;
        float pad = 12f;
        lake.transform.SetParent(parent, false);
        lake.transform.position = new Vector3((b.minX + b.maxX) / 2, info.waterLevel, (b.minZ + b.maxZ) / 2);
        lake.transform.localScale = new Vector3((b.maxX - b.minX + pad * 2) / 10f, 1, (b.maxZ - b.minZ + pad * 2) / 10f);
        lake.GetComponent<Renderer>().sharedMaterial = mat;

        // River: ribbon mesh along the centreline, sloping down toward the lake.
        var pts = info.river.points;
        if (pts == null || pts.Length < 2) return;
        var verts = new Vector3[pts.Length * 2];
        var uvs = new Vector2[pts.Length * 2];
        var tris = new int[(pts.Length - 1) * 6];
        float half = info.river.width / 2, dist = 0;
        for (int i = 0; i < pts.Length; i++)
        {
            var p = new Vector3(pts[i].x, pts[i].y, pts[i].z);
            var a = new Vector3(pts[Mathf.Max(i - 1, 0)].x, 0, pts[Mathf.Max(i - 1, 0)].z);
            var c = new Vector3(pts[Mathf.Min(i + 1, pts.Length - 1)].x, 0, pts[Mathf.Min(i + 1, pts.Length - 1)].z);
            var dir = (c - a).normalized;
            var side = new Vector3(-dir.z, 0, dir.x) * half;
            if (i > 0) dist += Vector3.Distance(new Vector3(pts[i - 1].x, pts[i - 1].y, pts[i - 1].z), p);
            verts[i * 2] = p - side; verts[i * 2 + 1] = p + side;
            uvs[i * 2] = new Vector2(0, dist / 10f); uvs[i * 2 + 1] = new Vector2(1, dist / 10f);
            if (i < pts.Length - 1)
            {
                int t = i * 6, v = i * 2;
                tris[t] = v; tris[t + 1] = v + 2; tris[t + 2] = v + 1;
                tris[t + 3] = v + 1; tris[t + 4] = v + 2; tris[t + 5] = v + 3;
            }
        }
        var mesh = new Mesh { name = "RiverMesh", vertices = verts, uv = uvs, triangles = tris };
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        AssetDatabase.DeleteAsset(Root + "/Generated/RiverMesh.asset");
        AssetDatabase.CreateAsset(mesh, Root + "/Generated/RiverMesh.asset");
        var river = new GameObject("River", typeof(MeshFilter), typeof(MeshRenderer));
        river.transform.SetParent(parent, false);
        river.GetComponent<MeshFilter>().sharedMesh = mesh;
        river.GetComponent<MeshRenderer>().sharedMaterial = mat;
    }

    static GameObject FindPrefab(string name)
    {
        foreach (var guid in AssetDatabase.FindAssets(name + " t:GameObject"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (Path.GetFileNameWithoutExtension(path) == name)
                return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }
        return null;
    }
}
#endif
