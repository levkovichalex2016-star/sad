using UnityEngine;

// Scrolls the water's ripple normal map so lakes and rivers look alive.
[RequireComponent(typeof(Renderer))]
public class GameMapWaterFlow : MonoBehaviour
{
    public Vector2 speed = new Vector2(0.004f, 0.002f);

    Material mat;
    Vector2 offset;

    void Start()
    {
        mat = GetComponent<Renderer>().material;   // per-object instance, keeps the asset unchanged
    }

    void Update()
    {
        if (mat == null || !mat.HasProperty("_BumpMap")) return;
        offset += speed * Time.deltaTime;
        mat.SetTextureOffset("_BumpMap", offset);
    }
}
